library(R.matlab)
library(tidyverse)


# DATA FILE NAME 
########################################################################################
main_addr = "Project/analysis/HstDDM/method_HtSSM_aDDM/convert/"
setwd(main_addr)

########################################################################################

type = 1

for(sess in 1:5){
  for(cond in 0:1){
    
    file = paste0("HDDM_results",type,"_sess",sess,"cond",cond,".csv")
    results <- read.csv(file)
    
    col_number  = 23*6
    data_ddm    = matrix(0,1,col_number)
    
    for(i in 1:23){
      var_name = paste0("b0.p[",i,"]")
      indx = which(results == var_name)
      data_ddm[1,(0*23)+i] = results$Mean[indx] 
    }

    
    for(i in 1:23){
      var_name = paste0("b1.p[",i,"]")
      indx = which(results == var_name)
      data_ddm[1,(1*23)+i] = results$Mean[indx] 
    }
    
    for(i in 1:23){
      var_name = paste0("b2.p[",i,"]")
      indx = which(results == var_name)
      data_ddm[1,(2*23)+i] = results$Mean[indx] 
    }
    
    for(i in 1:23){
      var_name = paste0("theta.p[",i,"]")
      indx = which(results == var_name)
      data_ddm[1,(3*23)+i] = results$Mean[indx] 
    }

    for(i in 1:23){
      var_name = paste0("bias.p[",i,"]")
      indx = which(results == var_name)
      data_ddm[1,(4*23)+i] = results$Mean[indx] 
    }

    for(i in 1:23){
      var_name = paste0("alpha.p[",i,"]")
      indx = which(results == var_name)
      data_ddm[1,(5*23)+i] = results$Mean[indx] 
    }

    data_ddm = data.table::as.data.table(data_ddm)
    varNames = c( "b0p1","b0p2","b0p3","b0p4","b0p5","b0p6","b0p7","b0p8","b0p9","b0p10","b0p11","b0p12","b0p13","b0p14","b0p15","b0p16","b0p17","b0p18","b0p19","b0p20","b0p21","b0p22","b0p23", 
                  "b1p1","b1p2","b1p3","b1p4","b1p5","b1p6","b1p7","b1p8","b1p9","b1p10","b1p11","b1p12","b1p13","b1p14","b1p15","b1p16","b1p17","b1p18","b1p19","b1p20","b1p21","b1p22","b1p23",         
                  "b2p1","b2p2","b2p3","b2p4","b2p5","b2p6","b2p7","b2p8","b2p9","b2p10","b2p11","b2p12","b2p13","b2p14","b2p15","b2p16","b2p17","b2p18","b2p19","b2p20","b2p21","b2p22","b2p23",
                  "thetap1","thetap2","thetap3","thetap4","thetap5","thetap6","thetap7","thetap8","thetap9","thetap10","thetap11","thetap12","thetap13","thetap14","thetap15","thetap16","thetap17","thetap18","thetap19","thetap20","thetap21","thetap22","thetap23",
                  "bias1","bias2","bias3","bias4","bias5","bias6","bias7","bias8","bias9","bias10","bias11","bias12","bias13","bias14","bias15","bias16","bias17","bias18","bias19","bias20","bias21","bias22","bias23",
                  "alphap1","alphap2","alphap3","alphap4","alphap5","alphap6","alphap7","alphap8","alphap9","alphap10","alphap11","alphap12","alphap13","alphap14", "alphap15","alphap16","alphap17","alphap18","alphap19","alphap20","alphap21","alphap22", "alphap23")
    colnames(data_ddm) = varNames

    
    mat_name = paste0("hddm_results",type,"_sess",sess,"cond",cond,".mat")
    R.matlab::writeMat(mat_name, data = data_ddm)
    
    
    
    R_name = paste0("hddm_results",type,"_sess",sess,"cond",cond,".RData")
    save(data_ddm, file=file.path(full_addr,R_name))
  }
}




