library(R.matlab)
library(tidyverse)


# DATA FILE NAME 
########################################################################################
main_addr = "Project/analysis/HstDDM/method_HtSSM_aDDM/convert/"
setwd(main_addr)

########################################################################################
type = 1

for(sess in 1:5){
  for(cond in 0:1){
    
    load(paste0("results",type,"_sess",sess,"cond",cond,".RData"))
    
    obj = as.data.frame(rbind(results$mcmc[[1]], results$mcmc[[2]], results$mcmc[[3]])) 
    
    col_number  = length(obj)
    row_number  = length(obj[[1]])
    data_ddm    = matrix(0,row_number,col_number)
    for(i in 1:col_number){
      data_ddm[1:row_number,i] = obj[[i]] %>% as.vector() %>% round(6)
    }
    data_ddm = data.table::as.data.table(data_ddm)
    varNames  = attributes(obj)$names
    
    # Parameters:
    # b0.mu       b1.mu       b2.mu       theta.mu      alpha.mu    bias.mu     time.mu       time.pr     
    # time[1]     time[2]     time[3]     time[4]       time[5]     time[6]     time[7]       time[8]       time[9]     time[10]        time[11]    time[12]      time[13]      time[14]        time[15]      time[16]      time[17]        time[18]      time[19]      time[20]      time[21]      time[22]      time[23]     
    # b0.p[1]     b0.p[2]     b0.p[3]     b0.p[4]       b0.p[5]     b0.p[6]     b0.p[7]       b0.p[8]       b0.p[9]     b0.p[10]        b0.p[11]     b0.p[12]     b0.p[13]      b0.p[14]        b0.p[15]      b0.p[16]      b0.p[17]        b0.p[18]      b0.p[19]      b0.p[20]      b0.p[21]      b0.p[22]      b0.p[23]    
    # b1.p[1]     b1.p[2]     b1.p[3]     b1.p[4]       b1.p[5]     b1.p[6]     b1.p[7]       b1.p[8]       b1.p[9]     b1.p[10]        b1.p[11]     b1.p[12]     b1.p[13]      b1.p[14]        b1.p[15]      b1.p[16]      b1.p[17]        b1.p[18]      b1.p[19]      b1.p[20]      b1.p[21]      b1.p[22]      b1.p[23]  
    # b2.p[1]     b2.p[2]     b2.p[3]     b2.p[4]       b2.p[5]     b2.p[6]     b2.p[7]       b2.p[8]       b2.p[9]     b2.p[10]        b2.p[11]     b2.p[12]     b2.p[13]      b2.p[14]        b2.p[15]       b2.p[16]     b2.p[17]        b2.p[18]      b2.p[19]      b2.p[20]      b2.p[21]      b2.p[22]      b2.p[23] 
    # theta.p[1]  theta.p[2]  theta.p[3]  theta.p[4]    theta.p[5]  theta.p[6]  theta.p[7]    theta.p[8]    theta.p[9]  theta.p[10]     theta.p[11] theta.p[12]   theta.p[13]   theta.p[14]     theta.p[15]   theta.p[16]   theta.p[17]     theta.p[18]   theta.p[19]   theta.p[20]   theta.p[21]   theta.p[22]   theta.p[23]  
    # bias[1]     bias[2]     bias[3]     bias[4]       bias[5]     bias[6]     bias[7]       bias[8]       bias[9]     bias[10]        bias[11]    bias[12]      bias[13]      bias[14]        bias[15]      bias[16]      bias[17]        bias[18]      bias[19]      bias[20]      bias[21]      bias[22]      bias[23] 
    # alpha.p[1]  alpha.p[2]  alpha.p[3]  alpha.p[4]    alpha.p[5]  alpha.p[6]  alpha.p[7]    alpha.p[8]    alpha.p[9]  alpha.p[10]     alpha.p[11] alpha.p[12]   alpha.p[13]   alpha.p[14]     alpha.p[15]   alpha.p[16]   alpha.p[17]     alpha.p[18]   alpha.p[19]   alpha.p[20]   alpha.p[21]   alpha.p[22]   alpha.p[23]
    # deviance
    
    varNames = c("b0mu","b1mu","b2mu","thetamu","alphamu","biasmu","timemu","timepr",
                 "time1","time2","time3","time4","time5","time6","time7","time8","time9","time10","time11","time12","time13","time14","time15","time16","time17","time18","time19","time20","time21","time22","time23",
                 "b0p1","b0p2","b0p3","b0p4","b0p5","b0p6","b0p7","b0p8","b0p9","b0p10","b0p11","b0p12","b0p13","b0p14","b0p15","b0p16","b0p17","b0p18","b0p19","b0p20","b0p21","b0p22","b0p23",
                 "b1p1","b1p2","b1p3","b1p4","b1p5","b1p6","b1p7","b1p8","b1p9","b1p10","b1p11","b1p12","b1p13","b1p14","b1p15","b1p16","b1p17","b1p18","b1p19","b1p20","b1p21","b1p22","b1p23",
                 "b2p1","b2p2","b2p3","b2p4","b2p5","b2p6","b2p7","b2p8","b2p9","b2p10","b2p11","b2p12","b2p13","b2p14","b2p15","b2p16","b2p17","b2p18","b2p19","b2p20","b2p21","b2p22","b2p23",
                 "thetap1","thetap2","thetap3","thetap4","thetap5","thetap6","thetap7","thetap8","thetap9","thetap10","thetap11","thetap12","thetap13","thetap14","thetap15","thetap16","thetap17","thetap18","thetap19","thetap20","thetap21","thetap22","thetap23",
                 "bias1","bias2","bias3","bias4","bias5","bias6","bias7","bias8","bias9","bias10","bias11","bias12","bias13","bias14","bias15","bias16","bias17","bias18","bias19","bias20","bias21","bias22","bias23",
                 "alphap1","alphap2","alphap3","alphap4","alphap5","alphap6","alphap7","alphap8","alphap9","alphap10","alphap11","alphap12","alphap13","alphap14", "alphap15","alphap16","alphap17","alphap18","alphap19","alphap20","alphap21","alphap22", "alphap23",
                 "deviance")
      
    colnames(data_ddm) = varNames
    
    mat_name = paste0("results",type,"_sess",sess,"cond",cond,".mat")
    R.matlab::writeMat(mat_name, data = data_ddm)
  }
}
