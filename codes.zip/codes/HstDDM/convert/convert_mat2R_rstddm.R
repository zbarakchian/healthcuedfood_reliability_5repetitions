
library(tidyverse)
library(data.table)


# DATA FILE NAME 
########################################################################################

main_addr = "Project/analysis/HstDDM/method_HtSSM_aDDM/convert/"
setwd(main_addr)

########################################################################################
type = 2; #1:left & 2:healthier

for(sess in 1:5){
  for(cond in 0:1){
  
  mat_name = paste0("data_ddm",type,"_sess",sess,"cond",cond,".mat")
  obj <- R.matlab::readMat(mat_name)
  
  col_number  = length(obj$Data)
  row_number  = length(obj$Data[[1]])
  data_ddm    = matrix(0,row_number,col_number)
  for(i in 1:col_number){
    data_ddm[1:row_number,i] = obj$Data[[i]] %>% as.vector() %>% round(6)
  }
  data_ddm    = as.data.table(data_ddm)
  # varNames = attributes(obj$Data)$dimnames[[1]]
  # varNames = c("choice","vt_l","vt_r","vh_l","vh_r","td","hd","rt","subject","challenge");
  varNames = c("choice","vt_1","vt_2","vh_1","vh_2","td","hd","rt","subject","challenge");
  colnames(data_ddm) = varNames
  
  rda_name = paste0("data",type,"_s",sess,"c",cond,".rda")
  save(data_ddm,file = rda_name)

  }
}
