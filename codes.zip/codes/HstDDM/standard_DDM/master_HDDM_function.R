fit_HDDM <-function(type, sess, cond) {

# type: L/R = 1, H/U = 2
# sess 1:5
# cond: 0 = Natural, 1 = Health cue

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
require(runjags)


data_name <- paste0("data",type,"_s",sess,"c",cond,".rda")
load(data_name)
Data = data_ddm

Data = Data[Data$rt>0.2,]

# RT is positive if left food item chosen, negative if right food item chosen
idx = which(Data$choice==0)
Data$RT <- Data$rt
Data$RT[idx] = Data$rt[idx] * -1

idxP = as.numeric(ordered(Data$subject)) #makes a sequentially numbered subj index

# scale value of health and taste difference
hd = scale(Data$hd)[,1]
td = scale(Data$td)[,1]

rtpos = Data$rt

y  = Data$RT
N  = length(y)
ns = length(unique(idxP))

#-----------------------------------------------------------------------------------------------------------------
# fit the model

# data
dat <- dump.format(list(N=N, y=y, idxP=idxP, hd=hd, td=td, rt=rtpos, ns=ns, c = 1))

# initial values for the parameters, it could also be created randomly.. make sure that the theta.mu initial value is smaller than the rt in each trial
inits1 <- dump.format(list( alpha.mu=0.5, alpha.pr=0.05, theta.mu=0.1,theta.pr=0.05, 
                            b0.mu = 0, b0.pr = 0.05,
                            b1.mu=0.3, b1.pr=0.05, b2.mu=0.01, b2.pr=0.05, bias.mu=0.4,
                            bias.kappa=1, y_pred=y,  .RNG.name="base::Super-Duper", .RNG.seed=99999))


inits2 <- dump.format(list( alpha.mu=0.16, alpha.pr=0.05,  theta.mu=0.2, theta.pr=0.05, 
                            b0.mu = 0.1, b0.pr = 0.05,
                            b1.mu=0.3, b1.pr=0.05, b2.mu=0.1, b2.pr=0.05, bias.mu=0.5,
                           bias.kappa=1, y_pred=y,  .RNG.name="base::Wichmann-Hill", .RNG.seed=1234))


inits3 <- dump.format(list( alpha.mu=0.2, alpha.pr=0.05, theta.mu=0.15, theta.pr=0.05,
                            b0.mu = -0.1, b0.pr = 0.05,
                            b1.mu=0.5, b1.pr=0.05, b2.mu=0.3, b2.pr=0.05, bias.mu=0.6,
                            bias.kappa=1, y_pred=y, .RNG.name="base::Mersenne-Twister", .RNG.seed=6666 ))

# parameters to monitor
monitor = c(
  "b0.mu", "b1.mu", "b2.mu", "theta.mu", "alpha.mu","bias.mu", "b0.p", "b1.p", "b2.p",  "theta.p", "bias.p","alpha.p", "deviance" )

# run the fitting
results <- run.jags(model="HDDM_model.txt", monitor=monitor, data=dat, n.chains=3, inits=c(inits1, inits2, inits3), plots = F, method="parallel", module="wiener", burnin=50000, sample=10000, thin=10)

save(results, Data, file=file.path("results/", paste0("HDDM_results",type,"_sess",sess,"cond",cond,".RData")))

suuum <- summary(results)
write.csv(suuum, file=file.path("results/", paste0("HDDM_results",type,"_sess",sess,"cond",cond,".csv")))

}
