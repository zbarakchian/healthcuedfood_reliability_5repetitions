
#########################################################################################

main_addr = "Project/analysis/brms/"
setwd(main_addr)

#########################################################################################

source("HDIofMCMC.R")

#--------------------------------------------------------------------------------------------------------------
###--------------------------choice brms ------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------
#-specify your choice type: 1 or 2 ? (1: left vs right), (2:healthier vs not-healthier)
type = 2;
load(paste0("results","_brms_choice",type,".rda"))
results_choice     <- results       
rm(results)

summary_choice     <- summary(results_choice)
data_choice        <- as.data.frame(results_choice$fit)

#compare chains across conditions, groups, etc ----
#--------------------------------------------------------------------------------------------------------------
output  = list(mean = NA, hdi = NA, post_prob = NA, post_dif = NA)

#-Attribute effect---------------------------------------------
col =  "b_Intercept"   #"b_condition1"  #"b_hd:condition1"    #"b_hd:session5" #"b_td"   #"b_Intercept"

#-Session effect-----------------------------------------------
col2 = "b_condition1:session2"
col3 = "b_condition1:session3"
col4 = "b_condition1:session4"
col5 = "b_condition1:session5"

#-----------------------
# col2 = "b_session2"
# col3 = "b_session3"
# col4 = "b_session4"
# col5 = "b_session5"

#-----------------------
# col2 = "b_td:session2"
# col3 = "b_td:session3"
# col4 = "b_td:session4"
# col5 = "b_td:session5"

#-----------------------
# col2 = "b_hd:session2"
# col3 = "b_hd:session3"
# col4 = "b_hd:session4"
# col5 = "b_hd:session5"

#-----------------------
# col2 = "b_hd:condition1:session2"
# col3 = "b_hd:condition1:session3"
# col4 = "b_hd:condition1:session4"
# col5 = "b_hd:condition1:session5"


#-----------------------
#-----------------------
# x = data_choice[[col]]
x = data_choice[[col5]] - data_choice[[col2]] 
#-------------------------------------------------------------------------------------------------------------
(output$mean       = mean(x))       # drift weight coefficient b1.mu
(output$hdi        = HDIofMCMC(x))  # Highest density interval (HDI)
(output$post_prob  = mean((x) < 0))  # 1-sided, directional test
(output$post_dif   = x)


#--------------------------------------------------------------------------------------------------------------
###--------------------------RT brms ------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------
type = 2;     
load(paste0("results","_brms_RT",type,".rda"))
results_RT         <- results
summary_RT         <- summary(results_RT)
data_RT            <- as.data.frame(results_RT$fit)

#compare chains across conditions, groups, etc ----
#--------------------------------------------------------------------------------------------------------------
output  = list(mean = NA, hdi = NA, post_prob = NA, post_dif = NA)

#-Attribute effect---------------------------------------------
col =  "b_Intercept"   #"b_condition1"  #"b_hd:condition1"    #"b_hd:session5" #"b_td"   #"b_Intercept"

#-Session effect-----------------------------------------------
col2 = "b_condition1:session2"
col3 = "b_condition1:session3"
col4 = "b_condition1:session4"
col5 = "b_condition1:session5"

#-----------------------
# col2 = "b_session2"
# col3 = "b_session3"
# col4 = "b_session4"
# col5 = "b_session5"

#-----------------------
# col2 = "b_td:session2"
# col3 = "b_td:session3"
# col4 = "b_td:session4"
# col5 = "b_td:session5"

#-----------------------
# col2 = "b_hd:session2"
# col3 = "b_hd:session3"
# col4 = "b_hd:session4"
# col5 = "b_hd:session5"

#-----------------------
# col2 = "b_hd:condition1:session2"
# col3 = "b_hd:condition1:session3"
# col4 = "b_hd:condition1:session4"
# col5 = "b_hd:condition1:session5"


#-----------------------
#-----------------------
# x = data_RT[[col]]
x = data_RT[[col5]] - data_RT[[col2]] 
#-------------------------------------------------------------------------------------------------------------
(output$mean       = mean(x))       # drift weight coefficient b1.mu
(output$hdi        = HDIofMCMC(x))  # Highest density interval (HDI)
(output$post_prob  = mean((x) < 0))  # 1-sided, directional test
(output$post_dif   = x)



