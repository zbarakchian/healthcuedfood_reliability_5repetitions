
library(brms); 
library(ggplot2); 

#########################################################################################

main_addr = "Project/analysis/brms"
setwd(full_addr)

#########################################################################################
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

## Specify colours
#--------------------------------------------------------------------------------------------------------------

color_cond       = c(rgb(255/255,178/255,102/255,1), 
                     rgb(0/255,153/255,153/255,1))

color_sc         = c(rgb(255/255,51/255,153/255,1),
                     rgb(51/255,153/255,255/255,1))

color_main       = c(rgb(0/255,206/255,209/255))


color_ctg        = c(rgb(255/255,51/255,51/255,1),
                     rgb(51/255,255/255,51/255,1),
                     rgb(153/255,51/255,255/255,1))

color_challenge  = c(rgb(255/255,51/255,51/255,1),
                     rgb(51/255,255/255,51/255,1),
                     rgb(153/255,51/255,255/255,1))

color_challenge  = c(rgb(102/255,178/255,255/255,1),
                     rgb(255/255,102/255,178/255,1),
                     rgb(128/255,128/255,128/255,1))

color_sess       = c(rgb(51/255,0/255,102/255,1),
                     rgb(127/255,0/255,255/255,1),
                     rgb(178/255,102/255,255/255,1),
                     rgb(255/255,153/255,255/255,1),
                     rgb(255/255,51/255,255/255,1))


color_fill        = c(rgb(160/255,160/255,160/255,1),
                      rgb(160/255,160/255,160/255,1),
                      rgb(160/255,160/255,160/255,1))

color_sess_fill = c("NA","NA","NA","NA","NA")

#--------------------------------------------------------------------------------------------------------------
###--------------------------choice brms ------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------
#-specify your choice type: 1 or 2 ? (1: left vs right), (2:healthier vs not-healthier)
type = 2;
load(paste0("results","_brms_choice",type,".rda"))
results_choice     <- results
summary_choice     <- summary(results_choice)
cond_ef_choice     <- brms::conditional_effects(results_choice, ask = FALSE)


#-Plot conditional effects
#--------------------------------------------------------------------------------------------------------------
cond_ef = cond_ef_choice

plot(cond_ef, plot = FALSE)[[1]] +  
  theme_classic() + 
  xlab("Taste difference") + ylab("Healthier choice")

plot(cond_ef, plot = FALSE)[[2]] +  
  theme_classic() + 
  xlab("Health difference") + ylab("Healthier choice")

plot(cond_ef, plot = FALSE)[[3]] +  
  theme_classic() + 
  xlab("Condition") + ylab("Healthier choice") 

plot(cond_ef, plot = FALSE)[[4]] +  
  theme_classic() + 
  xlab("Session") + ylab("Rating") +
  guides(fill=FALSE) +
  scale_colour_discrete(name  ="Attribute",
                        breaks=c("1", "2"),
                        labels=c("Taste", "Health"))


plot(cond_ef, plot = FALSE)[[4]] +  
  theme_classic() + 
  xlab("Session") + ylab("Healthier choice")




plot(cond_ef, plot = FALSE)[[5]] +
  theme_classic() +
  scale_colour_manual(values = color_cond) +
  scale_fill_manual(values = color_fill) +
  xlab("Taste difference") + ylab("Healthier choice")


plot(cond_ef, plot = FALSE)[[6]] +
  theme_classic() +
  scale_colour_manual(values = color_cond) +
  scale_fill_manual(values = color_fill) +
  xlab("Health difference") + ylab("Healthier choice") +
  ylim(0,1)



plot(cond_ef, plot = FALSE)[[7]] +
  theme_classic() +
  scale_colour_manual(values = color_sess) +
  scale_fill_manual(values = color_sess_fill ) +
  xlab("Taste difference") + ylab("Healthier choice")


plot(cond_ef, plot = FALSE)[[8]] +
  theme_classic() +
  scale_colour_manual(values = color_sess) +
  scale_fill_manual(values = color_sess_fill) +
  xlab("Health difference") + ylab("Healthier choice")


plot(cond_ef, plot = FALSE)[[9]] +
  theme_classic() +
  scale_colour_manual(values = color_sess) +
  scale_fill_manual(values = color_sess_fill) +
  xlab("Condition") + ylab("Healthier choice") +
  ylim(0,1)



#--------------------------------------------------------------------------------------------------------------
###--------------------------RT brms ------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------
type = 2;     
load(paste0("results","_brms_RT",type,".rda"))
results_RT         <- results
summary_RT         <- summary(results_RT)
cond_ef_RT         <- brms::conditional_effects(results_RT, ask = FALSE)

#-Plot conditional effects
#--------------------------------------------------------------------------------------------------------------
cond_ef = cond_ef_RT


plot(cond_ef, plot = FALSE)[[1]] +  
  theme_classic() +
  xlab("Taste difference") + ylab("log RT")

plot(cond_ef, plot = FALSE)[[2]] + 
  theme_classic() +
  xlab("Health difference") + ylab("log RT")

plot(cond_ef, plot = FALSE)[[3]] +  
  theme_classic() +
  xlab("Condition") + ylab("log RT")

plot(cond_ef, plot = FALSE)[[4]] +  
  theme_classic() +
  xlab("Session") + ylab("log RT")

plot(cond_ef, plot = FALSE)[[5]] +  
  theme_classic() +
  xlab("Challenging") + ylab("log RT")


plot(cond_ef, plot = FALSE)[[6]] +
  theme_classic() +
  scale_colour_manual(values = color_cond) +
  scale_fill_manual(values = color_fill) +
  xlab("Taste difference") + ylab("log RT") +
  ylim(0,0.25)



plot(cond_ef, plot = FALSE)[[7]] +
  theme_classic() +
  scale_colour_manual(values = color_cond) +
  scale_fill_manual(values = color_fill) +
  xlab("Health difference") + ylab("log RT") +
  ylim(0,0.25)



plot(cond_ef, plot = FALSE)[[8]] +
  theme_classic() +
  scale_colour_manual(values = color_sess) +
  scale_fill_manual(values = color_sess_fill ) +
  xlab("Taste difference") + ylab("log RT")


plot(cond_ef, plot = FALSE)[[9]] +
  theme_classic() +
  scale_colour_manual(values = color_sess) +
  scale_fill_manual(values = color_sess_fill) +
  xlab("Health difference") + ylab("log RT")


plot(cond_ef, plot = FALSE)[[10]] +
  theme_classic() +
  scale_colour_manual(values = color_sess) +
  scale_fill_manual(values = color_sess_fill) +
  xlab("Condition") + ylab("log RT") +
  ylim(0,0.25)


plot(cond_ef, plot = FALSE)[[11]] +
  theme_classic() +
  scale_colour_manual(values = color_challenge) +
  scale_fill_manual(values = color_fill) +
  xlab("Taste difference") + ylab("log RT")


plot(cond_ef, plot = FALSE)[[12]] +
  theme_classic() +
  scale_colour_manual(values = color_challenge) +
  scale_fill_manual(values = color_fill) +
  xlab("Health difference") + ylab("log RT")


plot(cond_ef, plot = FALSE)[[13]] +
  theme_classic() +
  scale_colour_manual(values = color_challenge) +
  scale_fill_manual(values = color_fill) +
  xlab("Condition") + ylab("log RT")


plot(cond_ef, plot = FALSE)[[14]] +
  theme_classic() +
  scale_colour_manual(values = color_challenge) +
  scale_fill_manual(values = color_fill) +
  xlab("Session") + ylab("log RT")



##-----------------------------------------------------------------------------------
conditions0 <- data.frame(condition = c(0))
conditions1 <- data.frame(condition = c(1))

# result = results_choice
result = results_RT

T0 = conditional_effects(result, effects = "td:session", conditions = conditions0)
T1 = conditional_effects(result, effects = "td:session", conditions = conditions1)
H0 = conditional_effects(result, effects = "hd:session", conditions = conditions0)
H1 = conditional_effects(result, effects = "hd:session", conditions = conditions1)


plot(T0, plot = FALSE)[[1]] + 
  theme_classic() +
  scale_colour_manual(values = color_sess) +
  scale_fill_manual(values = color_sess_fill ) +
  # ylim(0,1)    + xlab("Taste difference") + ylab("Healthier choice")
  ylim(0,0.25) + xlab("Taste difference") + ylab("log RT") 


plot(T1, plot = FALSE)[[1]] + 
  theme_classic() +
  scale_colour_manual(values = color_sess) +
  scale_fill_manual(values = color_sess_fill ) +
  # ylim(0,1) +  xlab("Taste difference") + ylab("Healthier choice")
  ylim(0,0.25) + xlab("Taste difference") + ylab("log RT")


plot(H0, plot = FALSE)[[1]] + 
  theme_classic() +
  scale_colour_manual(values = color_sess) +
  scale_fill_manual(values = color_sess_fill ) +
  # ylim(0,1) + xlab("Health difference") + ylab("Healthier choice")
  ylim(0,0.25) + xlab("Health difference") + ylab("log RT")



plot(H1, plot = FALSE)[[1]] + 
  theme_classic() +
  scale_colour_manual(values = color_sess) +
  scale_fill_manual(values = color_sess_fill ) +
  # ylim(0,1) + xlab("Health difference") + ylab("Healthier choice")
  ylim(0,0.25) + xlab("Health difference") + ylab("log RT")

