
library(data.table)
library(tidyverse); 

#########################################################################################

main_addr = "Project/analysis/brms/convert/"
setwd(main_addr)

#########################################################################################
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #


type = 1; # 1: left vs right ---- 2:healthier vs not-healthier

mat_file_name = paste0("data_brms_choice",type,".mat")
rda_file_name = paste0("data_brms_choice",type,".rda")



#########################################################################################
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

# Convert mat.data to rda data
obj <- R.matlab::readMat(mat_file_name)
col_number  = length(obj$Data)
row_number  = length(obj$Data[[1]])
data_reg    = matrix(0,row_number,col_number)
for(i in 1:col_number){
  data_reg[1:row_number,i] = obj$Data[[i]] %>% as.vector() %>% round(6)
}
data_reg = as.data.table(data_reg)

# varNames = attributes(obj$Data)$dimnames[[1]]
# varNames = c("choice","vt_l","vt_r","vh_l","vh_r","td","hd","rt","subject","challenge");
# varNames = c("choice","vt_l","vt_r","vh_l","vh_r","td","hd","sbj","session","condition","rt");
varNames = c("choice","challenge","vt_1","vt_2","vh_1","vh_2","td","hd","sbj","session","condition","rt");
# varNames = c("rating","sbj","session","dimension","category");

colnames(data_reg) = varNames
save(data_reg,file = rda_file_name)

#########################################################################################
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
