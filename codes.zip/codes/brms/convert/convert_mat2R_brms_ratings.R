
library(data.table)
library(tidyverse); 

#########################################################################################

main_addr = "Project/analysis/brms/convert/"
setwd(main_addr)

#########################################################################################
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

#########################################################################################
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
filename = "data_ratings4_session5"
mat_file_name = paste0(filename,".mat")

# Convert mat.data to rda data
obj <- R.matlab::readMat(mat_file_name)
obj = as.data.frame(obj) 

health = obj$X1.1$health
taste  = obj$X1.1$taste

rda_file_name = paste0(filename,"_health",".rda")
save(health, file = rda_file_name)

rda_file_name = paste0(filename,"_taste",".rda")
save(taste, file = rda_file_name)

#########################################################################################
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
