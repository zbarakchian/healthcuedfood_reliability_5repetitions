
library(brms); 

#-specify your address
#---------------------------------------------------------------------------------------------------------------- 
main_addr = "Project/analysis/brms"
setwd(main_addr)

#-specify your choice type: 1 or 2 ? (1: left vs right), (2:healthier vs not-healthier)
#---------------------------------------------------------------------------------------------------------------- 
type = 2; 

#-load data with the specified choice type
#---------------------------------------------------------------------------------------------------------------- 
data_name = paste0("data_brms_choice",type,".rda")
load(file.path(main_addr, data_name))

Data = data_reg
Data = Data[Data$rt>0.2,]

#---------------------------------------------------------------------------------------------------------------- 
#---------- Structure of the Data: Type1 (left vs right)
#
# choice      -> = 1 if left food item chosen, =0 if right food item chosen
#
# challenge   -> = 1 if (food1.health > food2.health && food1.taste < food2.taste) || (food1.health < food2.health && food1.taste > food2.taste), 
#                = 0 if opposite above, 
#                = NaN if any of the health or taste ratings of the two options is in the neutral zone
#
# vt_1        -> value taste  food item on the left  hand side of the screen
# vt_2        -> value taste  food item on the right hand side of the screen
# vh_1        -> value health food item on the left  hand side of the screen
# vh_2        -> value health food item on the right hand side of the screen
# td          -> value difference in taste  (td = vt_1 - vt_2)
# hd          -> value difference in health (hd = vh_1 - vh_2)
# sbj         -> subject number
# session     -> session number
# condition   -> condition number  (0 = natural condition, 1 = health-cued condition)
# rt          -> reaction time in seconds
# 
#---------------------------------------------------------------------------------------------------------------- 
#----------Structure of the Data: Type2 (healthier vs not-healthier)
#
# choice      -> = 1 if healthier food item chosen, =0 if not-healthier food item chosen
#
# challenge   -> = 1 if (food1.health > food2.health && food1.taste < food2.taste) || (food1.health < food2.health && food1.taste > food2.taste), 
#                = 0 if opposite above, 
#                = NaN if any of the health or taste ratings of the two options is in the neutral zone
#
# vt_1        -> value taste of the healthier option
# vt_2        -> value taste of the not-healthier option
# vh_1        -> value health of the healthier option
# vh_2        -> value health of the not-healthier option
# td          -> value difference in taste  (td = vt_1 - vt_2)
# hd          -> value difference in health (hd = vh_1 - vh_2)
# sbj         -> subject number
# session     -> session number
# condition   -> condition number  (0 = natural condition, 1 = health-cued condition)
# rt          -> reaction time in seconds
# 
#---------------------------------------------------------------------------------------------------------------- 


#-do factor the categorical variables
#---------------------------------------------------------------------------------------------------------------- 
Data$sbj       <- as.factor(Data$sbj)
Data$session   <- as.factor(Data$session)
Data$condition <- as.factor(Data$condition)
Data$challenge <- as.factor(Data$challenge)


# run the bayesian logistic regression for the choice outcomes
#---------------------------------------------------------------------------------------------------------------- 
results <- brm(
  choice ~ 1 + (td + hd) * condition * session + (1 + (td + hd) * condition * session || sbj),
  data = Data,
  # prior = priors,
  family = "bernoulli",
  seed = 123, # Adding a seed makes results reproducible.
  cores = 3,
  chains = 4,
  iter = 10000
)
save(results, file = paste0("results","_brms_choice",type,".rda"))



# run the bayesian regression for the reaction times
#---------------------------------------------------------------------------------------------------------------- 
Data$logRT   = log10(Data$rt)

results <- brm(
  logRT ~ 1 + (td + hd) * condition * session * challenge + (1 + (td + hd) * condition * session * challenge || sbj),
  data = Data,
  # prior = priors,
  family = gaussian(),
  seed = 123, # Adding a seed makes results reproducible.
  cores = 3,
  chains = 4,
  iter = 10000
)
save(results, file = paste0("results","_brms_RT",type,".rda"))



