
library(brms); 

#-specify your address
#---------------------------------------------------------------------------------------------------------------- 
main_addr = "Project/analysis/brms"
setwd(main_addr)

#-load data
#---------------------------------------------------------------------------------------------------------------- 
data_name = paste0("data_brms_rating.rda")
load(file.path(main_addr, data_name))

Data = data_reg

#-do factor the categorical variables
Data$sbj       <- as.factor(Data$sbj)
Data$session   <- as.factor(Data$session)
Data$dimension <- as.factor(Data$dimension)
Data$category  <- as.factor(Data$category)


#---------------------------------------------------------------------------------------------------------------- 
#run the bayesian regression for the ratings
results <- brm(
  rating ~ 1 + session * dimension * category + (1 + session * dimension * category || sbj),
  data = Data,
  # prior = priors,
  family = gaussian(),
  seed = 123, # Adding a seed makes results reproducible.
  cores = 2,
  chains = 4,
  iter = 10000
)
save(results, file = paste0("results_brms_rating.rda"))



