library('irr')

# DATA FILE NAME 
########################################################################################
main_addr = "Project/analysis/icc/"
setwd(main_addr)

########################################################################################
type = 1

n = 23
m = 5

matrix_b0       = matrix(0,n,m)
matrix_b1       = matrix(0,n,m)
matrix_b2       = matrix(0,n,m)
matrix_drift    = matrix(0,n,m)
matrix_theta    = matrix(0,n,m)
matrix_bias     = matrix(0,n,m)
matrix_alpha    = matrix(0,n,m)

#standard_ddm
for(sess in 1:5){
  
  cond = 1;
  
  file = paste0("HDDM_results",type,"_sess",sess,"cond",cond,".csv")
  data <- read.csv(file)
  
  
  for(sub in 1:23){
    
    ## matrix_b0[sub,sess] = data$Mean[b0.p[sub]]
    ## b0,b1,b2,theta,bias,aplpha,deviance
    
    
    var_name = paste0("b0.p[",sub,"]")
    indx = which(data == var_name)#, arr.ind = TRUE)
    command = paste("matrix_b0[sub,sess]", "=", "data$Mean[", indx,"]") 
    eval(parse(text=command))
    
    
    var_name = paste0("b1.p[",sub,"]")
    indx = which(data == var_name)
    command = paste("matrix_b1[sub,sess]", "=", "data$Mean[", indx,"]")
    eval(parse(text=command))
    
    
    var_name = paste0("b2.p[",sub,"]")
    indx = which(data == var_name)
    command = paste("matrix_b2[sub,sess]", "=", "data$Mean[", indx,"]")
    eval(parse(text=command))

    var_name0 = paste0("b0.p[",sub,"]")
    var_name1 = paste0("b1.p[",sub,"]")
    var_name2 = paste0("b2.p[",sub,"]")
    indx0 = which(data == var_name0)
    indx1 = which(data == var_name1)
    indx2 = which(data == var_name2)
    command = paste("matrix_drift[sub,sess]", "=", "data$Mean[", indx0, "]+data$Mean[", indx1, "]+data$Mean[", indx2,"]")
    eval(parse(text=command))
    
    var_name = paste0("theta.p[",sub,"]")
    indx = which(data == var_name)
    command = paste("matrix_theta[sub,sess]", "=", "data$Mean[", indx,"]")
    eval(parse(text=command))

    
    var_name = paste0("bias.p[",sub,"]")
    indx = which(data == var_name)
    command = paste("matrix_bias[sub,sess]", "=", "data$Mean[", indx,"]")
    eval(parse(text=command))

    var_name = paste0("alpha.p[",sub,"]")
    indx = which(data == var_name)
    command = paste("matrix_alpha[sub,sess]", "=", "data$Mean[", indx,"]")
    eval(parse(text=command))
    
  } 
}



icc(matrix_b0,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)


icc(matrix_b1,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)


icc(matrix_b2,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)


icc(matrix_drift,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)



icc(matrix_theta,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)



icc(matrix_bias,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)



icc(matrix_alpha,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)



########################################################################################
type = 1

n = 23
m = 5

matrix_b0       = matrix(0,n,m)
matrix_b1       = matrix(0,n,m)
matrix_b2       = matrix(0,n,m)
matrix_drift    = matrix(0,n,m)
matrix_theta    = matrix(0,n,m)
matrix_bias     = matrix(0,n,m)
matrix_alpha    = matrix(0,n,m)

for(sess in 1:5){
  
  cond = 0;
  file = paste0("HDDM_results",type,"_sess",sess,"cond",cond,".csv")
  data0 <- read.csv(file)
  
  cond = 1;
  file = paste0("HDDM_results",type,"_sess",sess,"cond",cond,".csv")
  data1 <- read.csv(file)

    
  for(sub in 1:23){
    

    var_name = paste0("b0.p[",sub,"]")
    indx0 = which(data0 == var_name)
    indx1 = which(data1 == var_name)
    command = paste("matrix_b0[sub,sess]", "=", "data0$Mean[",indx0,"] - data1$Mean[",indx1,"]") 
    eval(parse(text=command))

    
    var_name = paste0("b1.p[",sub,"]")
    indx0 = which(data0 == var_name)
    indx1 = which(data1 == var_name)
    command = paste("matrix_b1[sub,sess]", "=", "data0$Mean[",indx0,"] - data1$Mean[",indx1,"]") 
    eval(parse(text=command))

    var_name = paste0("b2.p[",sub,"]")
    indx0 = which(data0 == var_name)
    indx1 = which(data1 == var_name)
    command = paste("matrix_b2[sub,sess]", "=", "data0$Mean[",indx0,"] - data1$Mean[",indx1,"]") 
    eval(parse(text=command))
    
    
    var_name0 = paste0("b0.p[",sub,"]")
    var_name1 = paste0("b1.p[",sub,"]")
    var_name2 = paste0("b2.p[",sub,"]")
    indx00 = which(data0 == var_name0)
    indx01 = which(data0 == var_name1)
    indx02 = which(data0 == var_name2)
    indx10 = which(data1 == var_name0)
    indx11 = which(data1 == var_name1)
    indx12 = which(data1 == var_name2)
    command = paste("matrix_drift[sub,sess]", "=", "(data0$Mean[",indx00,"]","+ data0$Mean[",indx01,"]","+ data0$Mean[",indx02,"]", ") - (", "data1$Mean[",indx10,"]","+ data1$Mean[",indx11,"]","+ data1$Mean[",indx12,"])") 
    eval(parse(text=command))
    

    
    var_name = paste0("theta.p[",sub,"]")
    indx0 = which(data0 == var_name)
    indx1 = which(data1 == var_name)
    command = paste("matrix_theta[sub,sess]", "=", "data0$Mean[",indx0,"] - data1$Mean[",indx1,"]") 
    eval(parse(text=command))
    
    
    var_name = paste0("bias.p[",sub,"]")
    indx0 = which(data0 == var_name)
    indx1 = which(data1 == var_name)
    command = paste("matrix_bias[sub,sess]", "=", "data0$Mean[",indx0,"] - data1$Mean[",indx1,"]") 
    eval(parse(text=command))
    
    
    var_name = paste0("alpha.p[",sub,"]")
    indx0 = which(data0 == var_name)
    indx1 = which(data1 == var_name)
    command = paste("matrix_alpha[sub,sess]", "=", "data0$Mean[",indx0,"] - data1$Mean[",indx1,"]") 
    eval(parse(text=command))
    
  } 
}



icc(matrix_b0,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)


icc(matrix_b1,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)


icc(matrix_b2,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)


icc(matrix_drift,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)



icc(matrix_theta,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)



icc(matrix_bias,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)



icc(matrix_alpha,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)



