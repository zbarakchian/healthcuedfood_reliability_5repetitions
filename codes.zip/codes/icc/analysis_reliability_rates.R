library('irr')

# DATA FILE NAME 
########################################################################################
main_addr = "Project/analysis/icc/"
setwd(main_addr)

########################################################################################
type = 2

n    = 23
m    = 5


icc_cond_within = matrix(0,1,2)

for (cond in 0:1){

  matrix_rates = matrix(0,n,m)
  for(sess in 1:5){
    load(paste0("data",type,"_s",sess,"c",cond,".rda"));
    
    for(sub in 1:23){
      tmp = data_ddm [ data_ddm[["subject"]] == sub ] #      x[x == max(x)]
      choices = tmp[["choice"]]
      rates = mean(choices)
      matrix_rates[sub,sess] = rates
    }
  }
  
  out = icc(matrix_rates,
      model = "twoway",
      type = "agreement",
      unit = "single",
      r0 = 0,
      conf.level = 0.95)
  
  icc_cond_within[cond+1] = out$value

}


#------------------------------------------------------------------------
icc_cond_between = 0

matrix_rates = matrix(0,n,m)
for(sess in 1:5){
  cond = 0
  load(paste0("data",type,"_s",sess,"c",cond,".rda"));
  c0 = data_ddm
  
  cond = 1
  load(paste0("data",type,"_s",sess,"c",cond,".rda"));
  c1 = data_ddm
  
  rm(data_ddm)
  
  for(sub in 1:23){
    tmp0 = c0 [ c0[["subject"]] == sub ] #      x[x == max(x)]
    tmp1 = c1 [ c1[["subject"]] == sub ] #      x[x == max(x)]
    
    choices0 = tmp0[["choice"]] 
    choices1 = tmp1[["choice"]] 
    
    rates0 = mean(choices0)
    rates1 = mean(choices1)
    
    matrix_rates[sub,sess] = rates0 - rates1
  }
}

(icc_cond_between = icc(matrix_rates,
          model = "twoway",
          type = "agreement",
          unit = "single",
          r0 = 0,
          conf.level = 0.95))






