
library('irr')

# DATA FILE NAME 
########################################################################################
main_addr = "Project/analysis/icc/"
setwd(main_addr)

########################################################################################
## for subjects of all sessions 1:5,  60 images

k = 60
n = 23
m = 5

rely.health = matrix(0,n,1)
rely.taste  = matrix(0,n,1)

for(sub in 1:n){
  
  matrix_health = matrix(0,k,m)
  matrix_taste = matrix(0,k,m)
  
  for(sess in 1:m){
    load(paste0("data_ratings","_session",sess,"_health.rda"));
    load(paste0("data_ratings","_session",sess,"_taste.rda"));
    
    for(img in 1:k){
      matrix_health[img,sess] = health[img,sub];
      matrix_taste[img,sess]  = taste[img,sub];
    }
  }
  
  h = icc(matrix_health,
      model = "twoway",
      type = "agreement",
      unit = "single",
      r0 = 0,
      conf.level = 0.95)
  
  t = icc(matrix_taste,
      model = "twoway",
      type = "agreement",
      unit = "single",
      r0 = 0,
      conf.level = 0.95)
  
  rely.health[sub] = h$value
  rely.taste[sub]  = t$value
  
}


########################################################################################
## for subjects of session 1 and 5, 180 images

k = 180
n = 23
m = 2

rely.health = matrix(0,n,1)
rely.taste  = matrix(0,n,1)


for(sub in 1:n){
  
  matrix_health = matrix(0,k,m)
  matrix_taste  = matrix(0,k,m)
  
  for(sess in c(1,5)){
    load(paste0("data_ratings4","_session",sess,"_health.rda"));
    load(paste0("data_ratings4","_session",sess,"_taste.rda"));
    
    if (sess == 1){
      indx = 1
    }else { #(sess = 5)
      indx = 2
    }
    
    for(img in 1:k){
      matrix_health[img,indx] = health[img,sub];
      matrix_taste[img,indx]  = taste[img,sub];
    }
  }
  
  h = icc(matrix_health,
          model = "twoway",
          type = "agreement",
          unit = "single",
          r0 = 0,
          conf.level = 0.95)
  
  t = icc(matrix_taste,
          model = "twoway",
          type = "agreement",
          unit = "single",
          r0 = 0,
          conf.level = 0.95)
  
  rely.health[sub] = h$value
  rely.taste[sub]  = t$value
  
}

########################################################################################
## for images of all 5 sessions, 60 images

k = 60
n = 23
m = 5

rely.health = matrix(0,k,1)
rely.taste  = matrix(0,k,1)

for(img in 1:k){
  
  matrix_health = matrix(0,n,m)
  matrix_taste  = matrix(0,n,m)
  
  for(sess in 1:m){
    load(paste0("data_ratings","_session",sess,"_health.rda"));
    load(paste0("data_ratings","_session",sess,"_taste.rda"));
    
    for(sub in 1:n){
      matrix_health[sub,sess] = health[img,sub];
      matrix_taste[sub,sess]  = taste[img,sub];
    }
  }
  
  h = icc(matrix_health,
          model = "twoway",
          type = "agreement",
          unit = "single",
          r0 = 0,
          conf.level = 0.95)
  
  t = icc(matrix_taste,
          model = "twoway",
          type = "agreement",
          unit = "single",
          r0 = 0,
          conf.level = 0.95)
  
  rely.health[img] = h$value
  rely.taste[img]  = t$value
  
}


########################################################################################
## for images of session 1 and 5, 180 images

k = 180
n = 23
m = 2

rely.health = matrix(0,k,1)
rely.taste  = matrix(0,k,1)

for(img in 1:k){
  
  matrix_health = matrix(0,n,m)
  matrix_taste  = matrix(0,n,m)
  
  for(sess in c(1,5)){
    load(paste0("data_ratings4","_session",sess,"_health.rda"));
    load(paste0("data_ratings4","_session",sess,"_taste.rda"));
    
    if (sess == 1){
      indx = 1
    }else { #(sess = 5)
      indx = 2
    }
  
    for(sub in 1:n){
      matrix_health[sub,indx] = health[img,sub];
      matrix_taste[sub, indx] = taste[img,sub];
    }
  }
  
  h = icc(matrix_health,
          model = "twoway",
          type = "agreement",
          unit = "single",
          r0 = 0,
          conf.level = 0.95)
  
  t = icc(matrix_taste,
          model = "twoway",
          type = "agreement",
          unit = "single",
          r0 = 0,
          conf.level = 0.95)
  
  rely.health[img] = h$value
  rely.taste[img]  = t$value
  
}




