library('irr')

# DATA FILE NAME 
########################################################################################
main_addr = "Project/analysis/icc/"
setwd(main_addr)

########################################################################################
type = 1

n = 23
m = 5

matrix_b0       = matrix(0,n,m)
matrix_b1       = matrix(0,n,m)
matrix_b2       = matrix(0,n,m)
matrix_drift    = matrix(0,n,m)
matrix_time     = matrix(0,n,m)
matrix_theta    = matrix(0,n,m)
matrix_bias     = matrix(0,n,m)
matrix_alpha    = matrix(0,n,m)

for(sess in 1:5){
  
  cond = 0;
  load(paste0("results",type,"_sess",sess,"cond",cond,".RData"))
  data = data_ddm;
  
  for(sub in 1:23){
    
    ##---- ddm_matrix[sub,sess]  = mean(data$b0p1)
    ## b0,b1,b2,time,theta,bias,aplpha,deviance
  
    
    file_name = paste0("data$b0p",sub)
    command = paste("matrix_b0[sub,sess]", "=", "mean(", file_name,")")
    eval(parse(text=command))
    
    
    file_name = paste0("data$b1p",sub)
    command = paste("matrix_b1[sub,sess]", "=", "mean(", file_name,")")
    eval(parse(text=command))
    

    file_name = paste0("data$b2p",sub)
    command = paste("matrix_b2[sub,sess]", "=", "mean(", file_name,")")
    eval(parse(text=command))
    
    file_name1 = paste0("data$b1p",sub)
    file_name2 = paste0("data$b2p",sub)
    command = paste("matrix_drift[sub,sess]", "=", "mean(", file_name1,"+",file_name2,")")
    eval(parse(text=command))

    file_name = paste0("data$time",sub)
    command = paste("matrix_time[sub,sess]", "=", "mean(", file_name,")")
    eval(parse(text=command))

    
    file_name = paste0("data$thetap",sub)
    command = paste("matrix_theta[sub,sess]", "=", "mean(", file_name,")")
    eval(parse(text=command))

    
    file_name = paste0("data$bias",sub)
    command = paste("matrix_bias[sub,sess]", "=", "mean(", file_name,")")
    eval(parse(text=command))

    
    file_name = paste0("data$alphap",sub)
    command = paste("matrix_alpha[sub,sess]", "=", "mean(", file_name,")")
    eval(parse(text=command))

  } 
}



icc(matrix_b0,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)


icc(matrix_b1,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)


icc(matrix_b2,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)


icc(matrix_drift,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)


icc(matrix_time,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)


icc(matrix_theta,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)



icc(matrix_bias,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)



icc(matrix_alpha,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)



########################################################################################
type = 1

n = 23
m = 5

matrix_b0       = matrix(0,n,m)
matrix_b1       = matrix(0,n,m)
matrix_b2       = matrix(0,n,m)
matrix_drift    = matrix(0,n,m)
matrix_time     = matrix(0,n,m)
matrix_theta    = matrix(0,n,m)
matrix_bias     = matrix(0,n,m)
matrix_alpha    = matrix(0,n,m)

for(sess in 1:5){
  
  cond = 0;
  load(paste0("results",type,"_sess",sess,"cond",cond,".RData"))
  data0 = data_ddm;
  
  cond = 1;
  load(paste0("results",type,"_sess",sess,"cond",cond,".RData"))
  data1 = data_ddm;

  rm(data_ddm)
  
  for(sub in 1:23){
    
    file_name_c0 = paste0("data0$b0p",sub)
    file_name_c1 = paste0("data1$b0p",sub)
    command = paste("matrix_b0[sub,sess]", "=", "mean(", file_name_c1,"-",file_name_c0,")")
    eval(parse(text=command))
    
    
    file_name_c0 = paste0("data0$b1p",sub)
    file_name_c1 = paste0("data1$b1p",sub)
    command = paste("matrix_b1[sub,sess]", "=", "mean(", file_name_c1,"-",file_name_c0,")")
    eval(parse(text=command))
    
    
    file_name_c0 = paste0("data0$b2p",sub)
    file_name_c1 = paste0("data1$b2p",sub)
    command = paste("matrix_b2[sub,sess]", "=", "mean(", file_name_c1,"-",file_name_c0,")")
    eval(parse(text=command))
    
    
    file_name_c0_b1 = paste0("data0$b1p",sub)
    file_name_c0_b2 = paste0("data0$b2p",sub)
    file_name_c1_b1 = paste0("data1$b1p",sub)
    file_name_c1_b2 = paste0("data1$b2p",sub)
    command = paste("matrix_drift[sub,sess]", "=", "mean(","(" ,file_name_c1_b1,"+",file_name_c1_b2,")-(",file_name_c0_b1,"+",file_name_c0_b2,"))")   
    eval(parse(text=command))

    
    file_name_c0 = paste0("data0$time",sub)
    file_name_c1 = paste0("data1$time",sub)
    command = paste("matrix_time[sub,sess]", "=", "mean(", file_name_c1,"-",file_name_c0,")")
    eval(parse(text=command))
    
    
    file_name_c0 = paste0("data0$thetap",sub)
    file_name_c1 = paste0("data1$thetap",sub)
    command = paste("matrix_theta[sub,sess]", "=", "mean(", file_name_c1,"-",file_name_c0,")")
    eval(parse(text=command))
    
    
    file_name_c0 = paste0("data0$bias",sub)
    file_name_c1 = paste0("data1$bias",sub)
    command = paste("matrix_bias[sub,sess]", "=", "mean(", file_name_c1,"-",file_name_c0,")")
    eval(parse(text=command))
    
    
    file_name_c0 = paste0("data0$alphap",sub)
    file_name_c1 = paste0("data1$alphap",sub)
    command = paste("matrix_alpha[sub,sess]", "=", "mean(", file_name_c1,"-",file_name_c0,")")
    eval(parse(text=command))
    
  } 
}



icc(matrix_b0,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)


icc(matrix_b1,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)


icc(matrix_b2,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)


icc(matrix_drift,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)


icc(matrix_time,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)


icc(matrix_theta,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)



icc(matrix_bias,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)



icc(matrix_alpha,
    model = "twoway",
    type = "agreement", 
    unit = "single",
    r0 = 0,
    conf.level = 0.95)

