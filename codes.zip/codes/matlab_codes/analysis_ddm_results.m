function result =  analysis_ddm_results(sbjs,type,nsessions)

load(['results' num2str(type) '_ddm']);

credMass    = 0.95;
result      = [];

                  

%%
do.analysis_stability                           = 1;
do.attr_per_sess_cond                           = 0;
do.attr_per_cond                                = 0;
do.attr_per_sess                                = 0;
do.attr_overall                                 = 0;
do.across_attr_per_cond                         = 0; 
do.across_cond_overall                          = 0;
do.across_cond_per_sess                         = 0;
do.per_session_improvemen_per_cond              = 0;
do.per_session_improvemen_sum_cond              = 0;
do.per_session_improvement_across_cond          = 0;
do.cum_session_improvement_per_cond             = 0; 
do.cum_session_improvement_across_cond          = 0; 
do.analysis_other_params                        = 0;

%% prepare data
%--------------------------------------------------------------------------
[data_sc data_s data_c] = get_ddm_info(sbjs,nsessions,ddm);


%% 
if do.analysis_stability
    
analysis_stability(sbjs,type,nsessions); 

end

%% attr
%--------------------------------------------------------------------------
if do.attr_per_sess_cond
    
matrix = [];
for cond = 1:2
indx = 1;
for sess = 1:5
    
ab1                 = data_sc{sess,cond}.b1; 
b1.mean             = mean(ab1,1);
b1.hdi              = HDIofMCMC(ab1, credMass);
result.b1           = round([b1.mean   b1.hdi(1,:)],3);
matrix(indx,:,cond) = result.b1;
indx = indx + 1;
end

for sess = 1:5
    
ab2                 = data_sc{sess,cond}.b2;
b2.mean             = mean(ab2,1);
b2.hdi              = HDIofMCMC(ab2, credMass);
result.b2           = round([b2.mean   b2.hdi(1,:)],3);
matrix(indx,:,cond) = result.b2;
indx = indx + 1;

end

for sess = 1:5
    
ab1b2               = data_sc{sess,cond}.b1 - data_sc{sess,cond}.b2;
b1b2.mean           = mean(ab1b2,1);
b1b2.hdi            = HDIofMCMC(ab1b2, credMass);
result.b1b2         = round([b1b2.mean   b1b2.hdi(1,:)],3);
matrix(indx,:,cond) = result.b1b2;
indx = indx + 1;

end

for sess = 1:5
    
arst                = data_sc{sess,cond}.rst;
rst.mean            = mean(arst,1);
rst.hdi             = HDIofMCMC(arst,credMass);
result.rst          = round([rst.mean  rst.hdi(1,:)],3);
matrix(indx,:,cond) = result.rst;
indx = indx + 1;

end
end

result = matrix;
clearvars -except result
return

end

%%
if do.attr_per_cond
    


matrix = [];
for cond = 1:2
indx = 1;
    
ab1                 = data_c{cond}.b1; 
b1.mean             = mean(ab1,1);
b1.hdi              = HDIofMCMC(ab1, credMass);
result.b1           = round([b1.mean   b1.hdi(1,:)],3);
matrix(indx,:,cond) = result.b1;
indx = indx + 1;
%-----------    
ab2                 = data_c{cond}.b2;
b2.mean             = mean(ab2,1);
b2.hdi              = HDIofMCMC(ab2, credMass);
result.b2           = round([b2.mean   b2.hdi(1,:)],3);
matrix(indx,:,cond) = result.b2;
indx = indx + 1;

%-----------  
arst                = data_c{cond}.rst;
rst.mean            = mean(arst,1);
rst.hdi             = HDIofMCMC(arst,credMass);
result.rst          = round([rst.mean  rst.hdi(1,:)],3);
matrix(indx,:,cond) = result.rst;
indx = indx + 1;


end

result = matrix;
clearvars -except result
return

end
%%
%--------------------------------------------------------------------------
if do.attr_per_sess
    


matrix = [];
indx = 1;
for sess = 1:5
    
ab1                 = data_s.b1(:,sess); 
b1.mean             = mean(ab1,1);
b1.hdi              = HDIofMCMC(ab1, credMass);
result.b1           = round([b1.mean   b1.hdi(1,:)],3);
matrix(indx,:)      = result.b1;
indx = indx + 1;
end

for sess = 1:5
    
ab2                 = data_s.b2(:,sess); 
b2.mean             = mean(ab2,1);
b2.hdi              = HDIofMCMC(ab2, credMass);
result.b2           = round([b2.mean   b2.hdi(1,:)],3);
matrix(indx,:)      = result.b2;
indx = indx + 1;

end

for sess = 1:5
    
arst                = data_s.rst(:,sess);
rst.mean            = mean(arst,1);
rst.hdi             = HDIofMCMC(arst,credMass);
result.rst          = round([rst.mean  rst.hdi(1,:)],3);
matrix(indx,:)      = result.rst;
indx = indx + 1;

end

result = matrix;
clearvars -except result
return

end

%%
%--------------------------------------------------------------------------
if do.attr_overall
    

% ab1                 = mean(data_s.b1, 2); % data_s b1
% ab2                 = mean(data_s.b2, 2);
% arst                = mean(data_s.rst,2);
% 
% ab1                 = data_s.b1(:,1); %session1
% ab2                 = data_s.b2(:,1);
% arst                = data_s.rst(:,1);

cond = 1;
ab1                 = data_sc{1,cond}.b1; %session1
ab2                 = data_sc{1,cond}.b2;
arst                = data_sc{1,cond}.rst;

b1.mean             = mean(ab1,1);
b2.mean             = mean(ab2,1);
rst.mean            = mean(arst,1);

b1.hdi              = HDIofMCMC(ab1, credMass);
b2.hdi              = HDIofMCMC(ab2, credMass);
rst.hdi             = HDIofMCMC(arst,credMass);

result.b1           = round([b1.mean   b1.hdi(1,:)],3);
result.b2           = round([b2.mean   b2.hdi(1,:)],3);
result.rst          = round([rst.mean  rst.hdi(1,:)],3);
    

clearvars -except result
return

end



%% do.across_attr
if do.across_attr_per_cond
   
    
ac1b2_b1            = data_c{1}.b2  - data_c{1}.b1;
ac2b1_b2            = data_c{2}.b1  - data_c{2}.b2;

c1b2_b1.mean        = mean(ac1b2_b1,1);
c1b2_b1.hdi         = HDIofMCMC(ac1b2_b1, credMass);
result.c1b2_b1      = round([c1b2_b1.mean   c1b2_b1.hdi(1,:)],3);
    
c2b1_b2.mean        = mean(ac2b1_b2,1);
c2b1_b2.hdi         = HDIofMCMC(ac2b1_b2, credMass);
result.c2b1_b2      = round([c2b1_b2.mean   c2b1_b2.hdi(1,:)],3);


ac1rst              = data_c{1}.rst;
c1rst.mean          = mean(ac1rst,1);
c1rst.hdi           = HDIofMCMC(ac1rst, credMass);
result.c1rst        = round([c1rst.mean   c1rst.hdi(1,:)],3);


ac2rst              = data_c{2}.rst;
c2rst.mean          = mean(ac2rst,1);
c2rst.hdi           = HDIofMCMC(ac2rst, credMass);
result.c2rst        = round([c2rst.mean c2rst.hdi(1,:)],3);


clearvars -except result
return

end



%% across conditions
if do.across_cond_overall
    
ab0                 = data_c{2}.b0    - data_c{1}.b0;
ab1                 = data_c{2}.b1    - data_c{1}.b1;
ab2                 = data_c{1}.b2    - data_c{2}.b2;
ab1_b2              = (data_c{2}.b1   + (-data_c{2}.b2)) - (data_c{1}.b1  + (-data_c{1}.b2));
adrift              = (data_c{2}.b1   + data_c{2}.b2) - (data_c{1}.b1  + data_c{1}.b2);
arst                = data_c{2}.rst   - data_c{1}.rst;
atheta              = data_c{2}.theta - data_c{1}.theta;           
abias               = data_c{2}.bias  - data_c{1}.bias;           
aalpha              = data_c{2}.alpha - data_c{1}.alpha;           

b0.mean             = mean(ab0,1);
b0.hdi              = HDIofMCMC(ab0, credMass);
result.b0           = round([b0.mean   b0.hdi(1,:)],3);

b1.mean             = mean(ab1,1);
b1.hdi              = HDIofMCMC(ab1, credMass);
result.b1           = round([b1.mean   b1.hdi(1,:)],3);
    
b2.mean             = mean(ab2,1);
b2.hdi              = HDIofMCMC(ab2, credMass);
result.b2           = round([b2.mean   b2.hdi(1,:)],3);

b1_b2.mean          = mean(ab1_b2,1);
b1_b2.hdi           = HDIofMCMC(ab1_b2, credMass);
result.b1_b2        = round([b1_b2.mean   b1_b2.hdi(1,:)],3);

drift.mean          = mean(adrift,1);
drift.hdi           = HDIofMCMC(adrift, credMass);
result.drift        = round([drift.mean   drift.hdi(1,:)],3);

rst.mean            = mean(arst,1);
rst.hdi             = HDIofMCMC(arst, credMass);
result.rst          = round([rst.mean   rst.hdi(1,:)],3);

theta.mean          = mean(atheta,1);
theta.hdi           = HDIofMCMC(atheta, credMass);
result.theta        = round([theta.mean   theta.hdi(1,:)],3);

bias.mean           = mean(abias,1);
bias.hdi            = HDIofMCMC(abias, credMass);
result.bias         = round([bias.mean   bias.hdi(1,:)],3);

alpha.mean          = mean(aalpha,1);
alpha.hdi           = HDIofMCMC(aalpha, credMass);
result.alpha        = round([alpha.mean   alpha.hdi(1,:)],3);


clearvars -except result
return

end


%% across session condition
if do.across_cond_per_sess
    
for sess = 1:nsessions
    ab1         = data_sc{sess,2}.b1   - data_sc{sess,1}.b1;
    ab2         = data_sc{sess,2}.b2   - data_sc{sess,1}.b2;
    ab1_b2      = (data_sc{sess,2}.b1   - data_sc{sess,1}.b1) + (-(data_sc{sess,2}.b2   - data_sc{sess,1}.b2));
    arst        = data_sc{sess,2}.rst  - data_sc{sess,1}.rst;

    b1.mean     = mean(ab1,1);
    b2.mean     = mean(ab2,1);
    b1_b2.mean  = mean(ab1_b2,1);
    rst.mean    = mean(arst,1);

    
    b1.hdi      = HDIofMCMC(ab1,    credMass);
    b2.hdi      = HDIofMCMC(ab2,    credMass);
    b1_b2.hdi   = HDIofMCMC(ab1_b2, credMass);
    rst.hdi     = HDIofMCMC(arst,   credMass);

    result{sess}.b1     = [b1.mean       b1.hdi(1,:)];
    result{sess}.b2     = [b2.mean       b2.hdi(1,:)];
    result{sess}.b1b2   = [b1_b2.mean    b1_b2.hdi(1,:)];
    result{sess}.rst    = [rst.mean      rst.hdi(1,:)];
end

clearvars -except result
return

end


%% across session: separate conditions
if do.per_session_improvemen_per_cond
%--------------------------------------------------------------------------
k = 1;
%--------------------------------------------------------------------------
for cond = 1:2
    for sess = 2:nsessions
        b1.mean     = mean(data_sc{sess,cond}.b1  - data_sc{k,cond}.b1,1);
        b2.mean     = mean(data_sc{sess,cond}.b2  - data_sc{k,cond}.b2,1);
        rst.mean    = mean(data_sc{sess,cond}.rst - data_sc{k,cond}.rst,1);

        b1.hdi      = HDIofMCMC(data_sc{sess,cond}.b1  - data_sc{k,cond}.b1, credMass);
        b2.hdi      = HDIofMCMC(data_sc{sess,cond}.b2  - data_sc{k,cond}.b2, credMass);
        rst.hdi     = HDIofMCMC(data_sc{sess,cond}.rst - data_sc{k,cond}.rst,credMass);
        
        result.b1{cond}(sess,:)  = round([b1.mean   b1.hdi(1,:)],3);
        result.b2{cond}(sess,:)  = round([b2.mean   b2.hdi(1,:)],3);
        result.rst{cond}(sess,:) = round([rst.mean  rst.hdi(1,:)],3);
    end
end

clearvars -except result
return

end


%% across session 
if do.per_session_improvemen_sum_cond
%--------------------------------------------------------------------------
k = 1;
%--------------------------------------------------------------------------
for sess = 2:nsessions
    var_b1      = (data_sc{sess,1}.b1   - data_sc{k,1}.b1)  + (data_sc{sess,2}.b1   - data_sc{k,2}.b1);
    var_b2      = (data_sc{sess,1}.b2   - data_sc{k,1}.b2)  + (data_sc{sess,2}.b2   - data_sc{k,2}.b2);
    var_rst     = (data_sc{sess,1}.rst  - data_sc{k,1}.rst) + (data_sc{sess,2}.rst  - data_sc{k,2}.rst);
    
    b1.mean     = mean(var_b1,1);
    b2.mean     = mean(var_b2,1);
    rst.mean    = mean(var_rst,1);

    b1.hdi      = HDIofMCMC(var_b1, credMass);
    b2.hdi      = HDIofMCMC(var_b2, credMass);
    rst.hdi     = HDIofMCMC(var_rst,credMass);

    result.b1(sess,:)  = round([b1.mean   b1.hdi(1,:)],3);
    result.b2(sess,:)  = round([b2.mean   b2.hdi(1,:)],3);
    result.rst(sess,:) = round([rst.mean  rst.hdi(1,:)],3);
end

clearvars -except result
return

end



%% session_improvement_across_cond
if do.per_session_improvement_across_cond
 
%--------------------------------------------------------------------------
k = 1;
%--------------------------------------------------------------------------
for sess = 2:nsessions
    var_b1      = (data_sc{sess,1}.b1  - data_sc{k,1}.b1)  - (data_sc{sess,2}.b1   - data_sc{k,2}.b1);
    var_b2      = (data_sc{sess,1}.b2  - data_sc{k,1}.b2)  - (data_sc{sess,2}.b2   - data_sc{k,2}.b2);
    var_rst     = (data_sc{sess,1}.rst - data_sc{k,1}.rst) - (data_sc{sess,2}.rst  - data_sc{k,2}.rst);
    
    b1.mean     = mean(var_b1,1);
    b2.mean     = mean(var_b2,1);
    rst.mean    = mean(var_rst,1);

    b1.hdi      = HDIofMCMC(var_b1, credMass);
    b2.hdi      = HDIofMCMC(var_b2, credMass);
    rst.hdi     = HDIofMCMC(var_rst,credMass);

    result.b1(sess,:)  = round([b1.mean   b1.hdi(1,:)],3);
    result.b2(sess,:)  = round([b2.mean   b2.hdi(1,:)],3);
    result.rst(sess,:) = round([rst.mean  rst.hdi(1,:)],3);
end

    
clearvars -except result
return

end




%% session_improvement_across_cond group
if do.cum_session_improvement_per_cond

var_b1c1            =  (data_sc{5,1}.b1    - data_sc{1,1}.b1);               
var_b2c1            =  (data_sc{5,1}.b2    - data_sc{1,1}.b2);          
var_rstc1           =  (data_sc{5,1}.rst   - data_sc{1,1}.b2); 

var_b1c2            =  (data_sc{5,2}.b1    - data_sc{1,2}.b1);              
var_b2c2            =  (data_sc{5,2}.b2    - data_sc{1,2}.b2);
var_rstc2           =  (data_sc{5,2}.rst   - data_sc{1,2}.b2);

ab1c1.mean          = mean(var_b1c1,1);
ab1c1.hdi           = HDIofMCMC(var_b1c1, credMass);

ab2c1.mean          = mean(var_b2c1,1);
ab2c1.hdi           = HDIofMCMC(var_b2c1, credMass);

arstc1.mean         = mean(var_rstc1,1);
arstc1.hdi          = HDIofMCMC(var_rstc1, credMass);

ab1c2.mean          = mean(var_b1c2,1);
ab1c2.hdi           = HDIofMCMC(var_b1c2, credMass);

ab2c2.mean          = mean(var_b2c2,1);
ab2c2.hdi           = HDIofMCMC(var_b2c2, credMass);

arstc2.mean         = mean(var_rstc2,1);
arstc2.hdi          = HDIofMCMC(var_rstc2, credMass);       

%----------------------------------------------------------------------   
result{1}.health    = round([ab1c1.mean       ab1c1.hdi(1,:)],3);
result{1}.taste     = round([ab2c1.mean       ab2c1.hdi(1,:)],3);
result{1}.rst       = round([arstc1.mean      arstc1.hdi(1,:)],3);

result{2}.health    = round([ab1c2.mean       ab1c2.hdi(1,:)],3);
result{2}.taste     = round([ab2c2.mean       ab2c2.hdi(1,:)],3);
result{2}.rst       = round([arstc2.mean      arstc2.hdi(1,:)],3);
%----------------------------------------------------------------------   


clearvars -except result
return

end


%% 
if do.cum_session_improvement_across_cond

var_c1b1            = (data_sc{5,1}.b1  - data_sc{1,1}.b1);         
var_c1b2            = (data_sc{5,1}.b2  - data_sc{1,1}.b2);          
var_c1rst           = (data_sc{5,1}.rst - data_sc{1,1}.rst);
var_c2b1            = (data_sc{5,2}.b1  - data_sc{1,2}.b1);              
var_c2b2            = (data_sc{5,2}.b2  - data_sc{1,2}.b2);
var_c2rst           = (data_sc{5,2}.rst - data_sc{1,2}.rst); 

var_c12b1           = var_c1b1   - var_c2b1;
var_c12b2           = var_c1b2   - var_c2b2;
var_c12rst          = var_c1rst  - var_c2rst;
var_c1b12           = var_c1b1   + (-var_c1b2);
var_c2b12           = var_c2b1   + (-var_c2b2);
var_c12b12          = var_c1b12  - var_c2b12;
var_c12all          = var_c12b1  + (-var_c12b2) + (-var_c12rst);



ac12b1.mean         = mean(var_c12b1,1);
ac12b2.mean         = mean(var_c12b2,1);
ac12rst.mean        = mean(var_c12rst,1);
ac12b12.mean        = mean(var_c12b12,1);
ac12all.mean        = mean(var_c12all,1);


ac12b1.hdi          = HDIofMCMC(var_c12b1,          credMass);
ac12b2.hdi          = HDIofMCMC(var_c12b2,          credMass);
ac12rst.hdi         = HDIofMCMC(var_c12rst,         credMass);
ac12b12.hdi         = HDIofMCMC(var_c12b12,         credMass);
ac12all.hdi         = HDIofMCMC(var_c12all,         credMass);
  

result.c12b1        = round([ac12b1.mean        ac12b1.hdi(1,:)],3);
result.c12b2        = round([ac12b2.mean        ac12b2.hdi(1,:)],3);
result.c12rst       = round([ac12rst.mean       ac12rst.hdi(1,:)],3);
result.c12b12       = round([ac12b12.mean       ac12b12.hdi(1,:)],3);
result.c12all       = round([ac12all.mean       ac12all.hdi(1,:)],3);


clearvars -except result
return
end





%% analysis_other_params
if do.analysis_other_params
    
%reminder: theta: non-decision time, bias: bias, alpha: noise

ab0             = mean(data_s.b0,2);
atheta          = mean(data_s.theta,2);
abias           = mean(data_s.bias, 2);
aalpha          = mean(data_s.alpha,2);

b0.mean         = mean(ab0,1);
theta.mean      = mean(atheta,1);
bias.mean       = mean(abias, 1);
alpha.mean      = mean(aalpha,1);

b0.hdi          = HDIofMCMC(ab0, credMass);
theta.hdi       = HDIofMCMC(atheta, credMass);
bias.hdi        = HDIofMCMC(abias,  credMass);
alpha.hdi       = HDIofMCMC(aalpha, credMass);

result.b0       = round([b0.mean      b0.hdi(1,:)],3);
result.theta    = round([theta.mean   theta.hdi(1,:)],3);
result.bias     = round([bias.mean    bias.hdi(1,:)],3);
result.alpha    = round([alpha.mean   alpha.hdi(1,:)],3);
    
%-------------------
clearvars -except result
return

end

