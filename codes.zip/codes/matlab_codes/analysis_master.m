clear


%% sepecify type
%-(1:eft vs right) and (2: healthier vs not-healthier)
type = 1; 


%% sepecify what you intend to do!
do.primary_organization_steps       =  0;
do.reformat_datafor_brms            =  0;
do.reformat_datafor_ddm             =  0;
do.ddm_results_organize             =  0;
do.ddm_results_analyze              =  0;


%% participants
%--------------------------------------------------------------------------
subjects    = { 'a0115','a0312','a0729','a0321','a0113','b1031','b0604','d1220', ...
                'e1215','g0512','i0327','j0328','j0305','l0305','m0420','m1111',...
                'm1223','n0319','s0225','s0915','v0411','w0512','x0127' };
         
sbjs        = 1:length(subjects);
nsessions   = 5;



%% primary and necessary step for the next steps: data organization 
if do.primary_organization_steps

%-create a general file "data_trials", it is necessary for other analysis
organize_data_trials(sbjs,subjects);  

%-create a general file "data_ratings*", it is necessary for other analysis
organize_data_rating(sbjs,subjects);    

end


%%
if do.reformat_datafor_brms
    
%-create "data_brms*" for brms fitting in r
reformat_datafor_brms_choices(sbjs,type,nsessions);    
reformat_datafor_brms_ratings(sbjs,nsessions); 

end


%%
if do.reformat_datafor_ddm

%-create "data_ddm*" for ddm fitting in r
reformat_datafor_ddm(sbjs,type);

end


%==========================================================================
%
% In this step, you should convert following data files to r-related formats,
% and then run brms and ddm fitting analysis. There is a convert folder in
% each of the brms and ddm folders separately.
% files: {data_brms_choice*, data_ratings*_session*, data_ddm*_sess*cond*, }
% In matlab and r, the master files are the main codes you should start  
% with, which are: analysis_master.m, master_brms_choice.R, master_brms_rating.R, 
% After doing that, convert and return your ddm results (results*_sess*cond*) here to analysis with the
% following codes.
%
%==========================================================================


%%
if do.ddm_results_organize      
    
%-create "results_*ddm" file
organize_ddm_results(sbjs,nsessions,type);

end

%%
if do.ddm_results_analyze          

%-do analysis
result = analysis_ddm_results(sbjs,type,nsessions);
plot_ddm_results(type,sbjs,nsessions);
report_table_params_rstddm();
report_table_params_ddm();

end






















