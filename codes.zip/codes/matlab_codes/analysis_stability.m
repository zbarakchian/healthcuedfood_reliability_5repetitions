function analysis_stability(sbjs,type,nsessions)

load(['results' num2str(type) '_ddm']);

%%
for sub = sbjs
    for sess = 1:nsessions
        for cond = 1:2
            param.b1(sub,sess,cond)  = mean(ddm{sess,cond}.b1(:,sub));
            param.b2(sub,sess,cond)  = mean(ddm{sess,cond}.b2(:,sub));
            param.rst(sub,sess,cond) = mean(ddm{sess,cond}.time(:,sub));
        end
    end
end

for sub = sbjs
    for cond = 1:2
        range.b1(sub,cond)  = max(param.b1(sub,1:nsessions,cond))  - min(param.b1(sub,1:nsessions,cond));
        range.b2(sub,cond)  = max(param.b2(sub,1:nsessions,cond))  - min(param.b2(sub,1:nsessions,cond));
        range.rst(sub,cond) = max(param.rst(sub,1:nsessions,cond)) - min(param.rst(sub,1:nsessions,cond));
    end
end


% X = range.rst(:,1);
% Y = range.rst(:,2);
% [h,p,ci,stats] = ttest(X,Y);
% disp(p);
% 
% X = range.b1(:,1);
% Y = range.b1(:,2);
% [h,p,ci,stats] = ttest(X,Y);
% disp(p);
% 
% X = range.b2(:,1);
% Y = range.b2(:,2);
% [h,p,ci,stats] = ttest(X,Y);
% disp(p);


X = [range.b1(:,1); range.b2(:,1); range.rst(:,1)];
Y = [range.b1(:,2); range.b2(:,2); range.rst(:,2)];
[h,p,ci,stats] = ttest(X,Y);
disp(p);



% X = [range.b1(:,1);  range.b2(:,1)];
% Y = [range.rst(:,1)];
% [h,p,ci,stats] = ttest2(X,Y);
% disp(p);
% 
%   
% X = [range.b1(:,2);  range.b2(:,2)];
% Y = [range.rst(:,2)];
% [h,p,ci,stats] = ttest2(X,Y);
% disp(p);


X = [range.b1(:,1);  range.b1(:,2); range.b2(:,1); range.b2(:,2)];
Y = [range.rst(:,1); range.rst(:,2)];
[h,p,ci,stats] = ttest2(X,Y);
disp(p);



