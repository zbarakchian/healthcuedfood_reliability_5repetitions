function [data_cs data_s data_c] = get_ddm_info(sbjs,nsessions,ddm)


%% data_cs
%-----b1: health, b2: taste, rst:relative start time, theta: non-decision time, bias: bias, alpha: noise
for sess = 1:nsessions
    for cond = 1:2
        all{sess,cond}.b0     = mean(ddm{sess,cond}.b0(:,sbjs),2);
        all{sess,cond}.b1     = mean(ddm{sess,cond}.b1(:,sbjs),2);
        all{sess,cond}.b2     = mean(ddm{sess,cond}.b2(:,sbjs),2);
        all{sess,cond}.rst    = mean(ddm{sess,cond}.time(:,sbjs),2);  
        all{sess,cond}.theta  = mean(ddm{sess,cond}.theta(:,sbjs),2);
        all{sess,cond}.bias   = mean(ddm{sess,cond}.bias(:,sbjs),2);
        all{sess,cond}.alpha  = mean(ddm{sess,cond}.alpha(:,sbjs),2);  
    end
end
data_cs   = all;

%% data_s
tmp_b0 = []; tmp_b1 = [];  tmp_b2 = []; tmp_rst = []; tmp_theta = []; tmp_bias = []; tmp_alpha = [];
for sess = 1:nsessions
    for cond = 1:2
        tmp_b0     = [tmp_b0,  all{sess,cond}.b0];
        tmp_b1     = [tmp_b1,  all{sess,cond}.b1];
        tmp_b2     = [tmp_b2,  all{sess,cond}.b2];
        tmp_rst    = [tmp_rst, all{sess,cond}.rst];
        tmp_theta  = [tmp_theta, all{sess,cond}.theta];
        tmp_bias   = [tmp_bias,  all{sess,cond}.bias];
        tmp_alpha  = [tmp_alpha, all{sess,cond}.alpha];
    end
end

data_s.b0     = tmp_b0;
data_s.b1     = tmp_b1;
data_s.b2     = tmp_b2;
data_s.rst    = tmp_rst;
data_s.theta  = tmp_theta;
data_s.bias   = tmp_bias;
data_s.alpha  = tmp_alpha;

%% data_c
for cond = 1:2
    b0s= [];   b1s   = []; b2s   = []; rsts  = []; thetas = [];  biases = []; alphas = [];
    for sess = 1:nsessions
        b0s     = [b0s,    mean(ddm{sess,cond}.b0(:,sbjs),2)];
        b1s     = [b1s,    mean(ddm{sess,cond}.b1(:,sbjs),2)];
        b2s     = [b2s,    mean(ddm{sess,cond}.b2(:,sbjs),2)];
        rsts    = [rsts,   mean(ddm{sess,cond}.time(:,sbjs),2)];  
        thetas  = [thetas, mean(ddm{sess,cond}.theta(:,sbjs),2)];  
        biases  = [biases, mean(ddm{sess,cond}.bias(:,sbjs),2)];  
        alphas  = [alphas, mean(ddm{sess,cond}.alpha(:,sbjs),2)];  
    end
    condition{cond}.b0      = mean(b0s,2);
    condition{cond}.b1      = mean(b1s,2);
    condition{cond}.b2      = mean(b2s,2);
    condition{cond}.rst     = mean(rsts,2);
    condition{cond}.theta   = mean(thetas,2);
    condition{cond}.bias    = mean(biases,2);
    condition{cond}.alpha   = mean(alphas,2);
end
data_c  = condition;



