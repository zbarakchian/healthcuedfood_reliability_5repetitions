function category = healthy_tasty_else(sbjs)


load('data_ratings2');
images_spanned  = [4 5 7 8 10 11 15 19 20 21 30 31 34 36 37 39 47 55 59 64 67 68 69      ...
                   70 71 72 74 78 80 83 87 88 89 90 95 101 106 107 108 109 110 117       ...
                   120 121 122 124 125 126 128 132 149 154 156 158 161 163 166 168 169 178]';

               
data = [];
for sub = sbjs
    data(sub,1,:) = ratings_span{sub}{1}.health(:,2);
    data(sub,2,:) = ratings_span{sub}{1}.taste(:,2);
end


% for i=[2 18 23 33 44 46 53 55 56 57 58 60] %[5 55 69 89 121 124 156 161 163 166 168 178] %1:60
%     x = data(:,1,i);
%     y = data(:,2,i);
%     
%     lim = [0 450];
%     figure;
%     
%     scatter(x,y,...
%                70,...
%               'MarkerEdgeColor',[0 .5 .5],...
%               'MarkerFaceColor',[0 .7 .7],...
%               'LineWidth',1.5)    
%           
%           hold on
%     plot(lim,lim,'Color',[0.3 0.3 0.3], 'LineStyle','--','LineWidth',1.5);
%     
%     xlim(lim);
%     ylim(lim);
%     xlabel('health');
%     ylabel('taste');
%     
%     title(int2str(images_spanned(i)));
% end


%tasty      = 1;
%healthy    = 2;
%else       = 3

category = [1,3,1,1,1,1,2,2,2,2,2,3,2,1,1,3,2,3,1,2,3,2,3,1,1,1,2,3,1,3,3,1,3,1,2,1,1,2,3,1,1,1,2,2,1,1,1,1,3,1,2,2,3,3,2,1,3,3,3,3];




