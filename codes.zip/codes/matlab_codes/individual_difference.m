function individual_difference(type,nsessions)
load(['results' num2str(type) '_ddm']);

%%
plot_taste          = 1;
plot_health         = 1;
plot_rst            = 1;

%%
b1   = []; %health
b2   = []; %taste
rst  = [];

for sess = 1:nsessions
    for cond= 1:2
        data.b1     = ddm{sess,cond}.b1;
        data.b2     = ddm{sess,cond}.b2;
        data.time   = ddm{sess,cond}.time;
        
        
        b1(sess,cond,:)     = mean(data.b1,1);
        b2(sess,cond,:)     = mean(data.b2,1);
        rst(sess,cond,:)    = mean(data.time,1);
    end
end
disp(' ');



%%
if plot_taste
f = figure;

% subplot(1,2,1)

x(:,:) = b2(:,1,:);
box1 = boxplot(x,'BoxStyle','outline');
% set(box1, ...
%     'Colors', [0.5,0.5,05]);

hold on;
plot(0:24, repmat(0.5,1,25),'Color',[.5 .5 .5],'LineStyle','--','LineWidth',1);

xlabel('subjects')
ylabel('taste weight')
ylim([-1.5 2])
% title('natural-cued condition')

nameRate = strcat('Figures', filesep, 'taste_cond_natural.png');
saveas(gcf,nameRate);
close(f);


%--------------------------------------------------------------------------
% subplot(1,2,2)
f = figure;

x(:,:) = b2(:,2,:);
box2 = boxplot(x,'BoxStyle','outline');

hold on;
plot(0:24, repmat(0.5,1,25),'Color',[.5 .5 .5],'LineStyle','--','LineWidth',1);

xlabel('subjects')
ylabel('taste weight')
ylim([-1.5 2])
% title('health-cued condition')

nameRate = strcat('Figures', filesep, 'taste_cond_health.png');
saveas(gcf,nameRate);
close(f);


end

%%
if plot_health
    
f = figure;

% subplot(1,2,1)
x(:,:) = b1(:,1,:);
box1 = boxplot(x,'BoxStyle','outline');
% set(box1, ...
%     'Colors', [0.5,0.5,05]);

hold on;
plot(0:24, repmat(0.5,1,25),'Color',[.5 .5 .5],'LineStyle','--','LineWidth',1);


xlabel('subjects')
ylabel('health weight')
ylim([-1.5 2])
% title('natural-cued condition')

nameRate = strcat('Figures', filesep, 'health_cond_natural.png');
saveas(gcf,nameRate);
close(f);


%--------------------------------------------------------------------------
% subplot(1,2,2)
f = figure;

x(:,:) = b1(:,2,:);
box2 = boxplot(x,'BoxStyle','outline');

hold on;
plot(0:24, repmat(0.5,1,25),'Color',[.5 .5 .5],'LineStyle','--','LineWidth',1);

xlabel('subjects')
ylabel('health weight')
ylim([-1.5 2])
% title('health-cued condition')

nameRate = strcat('Figures', filesep, 'health_cond_health.png');
saveas(gcf,nameRate);
close(f);


end
%%
if plot_rst
f = figure;

% subplot(1,2,1)
x(:,:) = rst(:,1,:);
box1 = boxplot(x,'BoxStyle','outline');
% set(box1, ...
%     'Colors', [0.5,0.5,05]);

hold on;
plot(0:24, repmat(0,1,25),'Color',[.5 .5 .5],'LineStyle','--','LineWidth',1);

xlabel('subjects')
ylabel('relative start time: health - taste')
ylim([-.1 0.3])
% title('natural-cued condition')

nameRate = strcat('Figures', filesep, 'rst_cond_natural.png');
saveas(gcf,nameRate);
close(f);


%--------------------------------------------------------------------------
% subplot(1,2,2)
f = figure;

x(:,:) = rst(:,2,:);
box2 = boxplot(x,'BoxStyle','outline');

hold on;
plot(0:24, repmat(0,1,25),'Color',[.5 .5 .5],'LineStyle','--','LineWidth',1);

xlabel('subjects')
ylabel('relative start time: health - taste')
ylim([-.1 0.3])
% title('health-cued condition')

nameRate = strcat('Figures', filesep, 'rst_cond_health.png');
saveas(gcf,nameRate);
close(f);


end
