function ratings = organize_data_rating(sbjs,subjects)


addr_mainresult = 'Data_behavioural_lab';
addr_results    = {'ResultsDay1','ResultsDay2','ResultsDay3','ResultsDay4','ResultsDay5'};

images_all      = [1:180]';
images_spanned  = [4 5 7 8 10 11 15 19 20 21 30 31 34 36 37 39 47 55 59 64 67 68 69      ...
                   70 71 72 74 78 80 83 87 88 89 90 95 101 106 107 108 109 110 117       ...
                   120 121 122 124 125 126 128 132 149 154 156 158 161 163 166 168 169 178]';

               
%%
sessions    = 1:5;
ratings     = [];
for sub = sbjs
    sub_name = subjects{sub};
    
    for session = sessions
        if session == 1 || session == 5
            images = images_all;
        else
            images = images_spanned;
        end
        
        result_addr = [addr_mainresult filesep addr_results{session}];
        
        filenames  = dir([result_addr filesep 'results_health_*',sub_name,'system*_day_',num2str(session),'.mat']); 
        filename   = [filenames(1).name];
        load([result_addr filesep filename]); 
        tmp = [image_order', responses_in_image_order];
        tmp = sortrows(tmp);
        food.health = [images, tmp(:,2)];

        filenames  = dir([result_addr filesep 'results_taste_*', sub_name,'system*_day_',num2str(session),'.mat']); 
        filename   = [filenames(1).name];
        load([result_addr filesep filename]); 
        tmp = [image_order', responses_in_image_order];
        tmp = sortrows(tmp);
        food.taste = [images, tmp(:,2)];

        ratings{sub}{session} = food;
    end    
end


save('data_ratings','ratings');

%%

load('data_ratings');

images_all     = ratings{1}{1}.health(:,1);
images_spanned = ratings{1}{2}.health(:,1);


ratings_span = [];
for sub = sbjs
    indx = 1;
    for session = 1:5
        if session == 1 || session == 5
            ratings_span{sub}{session}.health = ratings{sub}{session}.health(images_spanned,:);
            ratings_span{sub}{session}.taste  = ratings{sub}{session}.taste(images_spanned,:);
            
            ratings15{sub}{indx} = ratings{sub}{session}; indx = indx + 1;
        else
            ratings_span{sub}{session} = ratings{sub}{session};
        end
    end
end

save('data_ratings2','ratings15','ratings_span');


%%

% load('data_ratings2');
% 
% ratings = [];
% for sess = 1:5
%     for sub = sbjs
%         ratings.health(:,sub) = ratings_span{sub}{sess}.health(:,2);
%         ratings.taste(:,sub)  = ratings_span{sub}{sess}.taste(:,2);
%     end
%     save(['data_ratings3_session' int2str(sess)],'ratings');
% end


%%
% load('data_ratings2');
% 
% ratings = [];
% for sess = 1:2
%     for sub = sbjs
%         ratings.health(:,sub) = ratings15{sub}{sess}.health(:,2);
%         ratings.taste(:,sub)  = ratings15{sub}{sess}.taste(:,2);
%     end
%     save(['data_ratings4_session' int2str(sess)],'ratings');
% end



