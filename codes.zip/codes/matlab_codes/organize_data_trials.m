function trials = organize_data_trials(sbjs,subjects)


addr_mainresult = 'Data_behavioural_lab';
addr_results    = {'ResultsDay1','ResultsDay2','ResultsDay3','ResultsDay4','ResultsDay5'};

%%
sessions        = 1:5;
rruns           = 1:3;

%%
data = [];
for sub = sbjs
    sub_name = subjects{sub};
    
    data_session = [];    
    for sess = sessions
        result_addr = [addr_mainresult filesep addr_results{sess}];

        for r = rruns
            filenames  = dir([result_addr filesep 'food_choices_',sub_name,'system*_',num2str(r),'_day_',num2str(sess),'.mat']); 
            filename   = [filenames(1).name];
            load([result_addr filesep filename]); 
            data_session.responses{r}  = responses;
            data_session.H_colors{r}   = H_color;
            
            for block = 1:length(timing) 
                for regblock = 1:length(timing{block})
                   rt{block}{regblock} = timing{block}{regblock}.reaction_times;
                end
            end
            data_session.rt{r} = rt; 
        end

        filenames  = dir([result_addr filesep 'HvNvec_',sub_name,'system*_day_',num2str(sess),'.mat']); 
        filename   = [filenames(1).name];
        load([result_addr filesep filename]); 
        data_session.HvNvec   = HvNvec;

        filenames  = dir([result_addr filesep 'imagelist_',sub_name,'system*_day_',num2str(sess),'.mat']); 
        filename   = [filenames(1).name];
        load([result_addr filesep filename]); 
        data_session.foods   = {food1,food2}; %food1 = left, food2 = right
        data_session.vectors = vectors;

        filenames  = dir([result_addr filesep 'parms_bic_',sub_name,'system*_day_',num2str(sess),'.mat']); 
        filename   = [filenames(1).name];
        load([result_addr filesep filename]); 
        data_session.runs = runs;

        filenames  = dir([result_addr filesep 'hunger_rating_',sub_name,'system*_day_',num2str(sess),'.mat']); 
        filename   = [filenames(1).name];
        load([result_addr filesep filename]); 
        data_session.hunger = {responses,scale_direction};

%         filenames  = dir([result_addr filesep 'results_health_',sub,'system*_day_',num2str(session),'.mat']); 
%         filename   = [filenames(1).name];
%         load([result_addr filesep filename]); 

%         filenames  = dir([result_addr filesep 'results_taste_',sub,'system*_day_',num2str(session),'.mat']); 
%         filename   = [filenames(1).name];
%         load([result_addr filesep filename]); 

        data{sub}{sess} = data_session;
    end    
end
%%

trials = [];
for sub = sbjs    
    for sess = sessions  
        
        not_in_nulltrials  = data{sub}{sess}.vectors.trialIDs;
        indx_block   = 1;  
        indx_trial_X = 1;
        indx_trial_s = 1;

        for run = 1:length(data{sub}{sess}.responses)
            for block = 1:length(data{sub}{sess}.responses{run}) 
                for regblock = 1:length(data{sub}{sess}.responses{run}{block})
                    for trial = 1:length(data{sub}{sess}.responses{run}{block}{regblock}) 
                        if not_in_nulltrials(indx_trial_X) 
                            
                            trials{sub}{sess}.condition(indx_trial_s,1)          = data{sub}{sess}.HvNvec(indx_block);
                            trials{sub}{sess}.choice(indx_trial_s,1)             = data{sub}{sess}.responses{run}{block}{regblock}(trial);     
                            trials{sub}{sess}.rt(indx_trial_s,1)                 = data{sub}{sess}.rt{run}{block}{regblock}(trial);     
                            trials{sub}{sess}.food{1}.health(indx_trial_s,1)     = data{sub}{sess}.foods{1}(indx_trial_s,2);
                            trials{sub}{sess}.food{1}.taste(indx_trial_s,1)      = data{sub}{sess}.foods{1}(indx_trial_s,3);
                            trials{sub}{sess}.food{2}.health(indx_trial_s,1)     = data{sub}{sess}.foods{2}(indx_trial_s,2);
                            trials{sub}{sess}.food{2}.taste(indx_trial_s,1)      = data{sub}{sess}.foods{2}(indx_trial_s,3);

                            indx_trial_s = indx_trial_s + 1;
                        end
                        indx_trial_X = indx_trial_X + 1;
                    end
                end
                indx_block = indx_block + 1;                
            end
        end 
    end
end
%%
save('data_trials','trials');


