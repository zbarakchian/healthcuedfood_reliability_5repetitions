function organize_ddm_results(sbjs,nsessions,type)

for sess = 1:nsessions
    for cond = 1:2
        tmp{sess,cond} = load(['results',int2str(type),'_sess',int2str(sess),'cond',int2str(cond-1),'.mat']);        
    end
end

for sess = 1:nsessions
    for cond = 1:2
        for sub = sbjs
            name = ['b0p' int2str(sub)];
            ddm{sess,cond}.b0(:,sub) = tmp{sess,cond}.data.(name);

            name = ['b1p' int2str(sub)];
            ddm{sess,cond}.b1(:,sub) = tmp{sess,cond}.data.(name);
            
            name = ['b2p' int2str(sub)];
            ddm{sess,cond}.b2(:,sub) = tmp{sess,cond}.data.(name);    

            name = ['time' int2str(sub)];
            ddm{sess,cond}.time(:,sub) = tmp{sess,cond}.data.(name);    
        
            name = ['thetap' int2str(sub)];
            ddm{sess,cond}.theta(:,sub) = tmp{sess,cond}.data.(name);    

            name = ['bias' int2str(sub)];
            ddm{sess,cond}.bias(:,sub) = tmp{sess,cond}.data.(name);   
            
            name = ['alphap' int2str(sub)];
            ddm{sess,cond}.alpha(:,sub) = tmp{sess,cond}.data.(name); 
            
        end
        ddm{sess,cond}.deviance = tmp{sess,cond}.data.deviance; 

    end
end


save(['results',int2str(type),'_ddm'],'ddm');
disp('end!');

