function plot_parameters(sbjs,type,nsessions)
load(['results' num2str(type) '_ddm']);


%-Choose which figure you want to plot!
%--------------------------------------------------------------------------
plot_condition       = 1;
plot_weight          = 0;
plot_rst             = 1;


%%
b1   = [];
b2   = [];
rst  = [];

for sess = 1:nsessions
    for cond= 1:2
        data.b1             = ddm{sess,cond}.b1(:,sbjs);
        data.b2             = ddm{sess,cond}.b2(:,sbjs);
        data.time           = ddm{sess,cond}.time(:,sbjs);
        
        
        b1(:,sess,cond)     = mean(data.b1,2);
        b2(:,sess,cond)     = mean(data.b2,2);
        rst(:,sess,cond)    = mean(data.time,2);
    end
end

%%

color1 = [255,178,102]/255; %orange
color2 = [0,153,153]/255;   %green



%% natural-cued condition vs health-cued condition
if plot_condition


%-neutral
figure;

% subplot(1,2,1);
x = [1:nsessions];

y1(:,:) = b2(:,1:nsessions,1);
y2(:,:) = b2(:,1:nsessions,2);

y1m = mean(y1,1);
y2m = mean(y2,1);
y1h = []; y2h = [];
for sess = 1:nsessions
    hdi = HDIofMCMC(y1(:,sess),0.95);
    y1h(sess) = hdi(2) - hdi(1);
    
    hdi = HDIofMCMC(y2(:,sess),0.95);
    y2h(sess) = hdi(2) - hdi(1);
end

sh = shadedErrorBar_origin(x,y1m,y1h,'lineprops',{'LineStyle','-','LineWidth',2,'Color',color1});
component{1} = sh.mainLine;

hold on
sh  = shadedErrorBar_origin(x,y2m,y2h,'lineprops',{'LineStyle','-','LineWidth',2,'Color',color2});
component{2} = sh.mainLine;

hold on
plot(x,repmat(y1m(1),1,length(x)),'Color',color1,'LineStyle',':','LineWidth',1.5);
hold on
plot(x,repmat(y1m(nsessions),1,length(x)),'Color',color1,'LineStyle',':','LineWidth',1.5);


hold on
plot(x,repmat(y2m(1),1,length(x)),'Color',color2,'LineStyle',':','LineWidth',1.5);
hold on
plot(x,repmat(y2m(nsessions),1,length(x)),'Color',color2,'LineStyle',':','LineWidth',1.5);


xlabel('session');
ylabel('taste weight');

ylim([-1 2]);
% title('taste weight');

hLegend = legend( ...
  [component{1}, component{2}], ...
  ['Natural-cued condition'] , ...
  ['Health-cued Condition'] , ...
  'location', 'NorthWest');

legend boxoff;  

set(gca, ...
  'Box'         , 'off'     , ...
  'TickDir'     , 'out'     , ...
  'TickLength'  , [.02 .02] , ...
  'XMinorTick'  , 'off'     , ...
  'YMinorTick'  , 'off'     , ...
  'XColor'      , [.3 .3 .3], ...
  'YColor'      , [.3 .3 .3], ...
  'XTick'       , 0:1:nsessions     , ...
  'XGrid'       , 'off'      , ...
  'YGrid'       , 'off'      , ...
  'LineWidth'   , 1         );


%-health
% subplot(1,2,2);
figure;

y1(:,:) = b1(:,1:nsessions,1);
y2(:,:) = b1(:,1:nsessions,2);

y1m = mean(y1,1);
y2m = mean(y2,1);
y1h = []; y2h = [];
for sess = 1:nsessions
    hdi = HDIofMCMC(y1(:,sess),0.95);
    y1h(sess) = hdi(2) - hdi(1);
    
    hdi = HDIofMCMC(y2(:,sess),0.95);
    y2h(sess) = hdi(2) - hdi(1);
end

sh = shadedErrorBar_origin(x,y1m,y1h,'lineprops',{'LineStyle','-','LineWidth',2,'Color',color1});
component{1} = sh.mainLine;

hold on
sh  = shadedErrorBar_origin(x,y2m,y2h,'lineprops',{'LineStyle','-','LineWidth',2,'Color',color2});
component{2} = sh.mainLine;

hold on
plot(x,repmat(y1m(1),1,length(x)),'Color',color1,'LineStyle',':','LineWidth',1.5);
hold on
plot(x,repmat(y1m(nsessions),1,length(x)),'Color',color1,'LineStyle',':','LineWidth',1.5);


hold on
plot(x,repmat(y2m(1),1,length(x)),'Color',color2,'LineStyle',':','LineWidth',1.5);
hold on
plot(x,repmat(y2m(nsessions),1,length(x)),'Color',color2,'LineStyle',':','LineWidth',1.5);


xlabel('session');
ylabel('health weight');

ylim([-1 2]);
% title('health weight');

hLegend = legend( ...
  [component{1}, component{2}], ...
  ['Natural-cued condition'] , ...
  ['Health-cued Condition'] , ...
  'location', 'NorthWest');

legend boxoff;  

set(gca, ...
  'Box'         , 'off'     , ...
  'TickDir'     , 'out'     , ...
  'TickLength'  , [.02 .02] , ...
  'XMinorTick'  , 'off'     , ...
  'YMinorTick'  , 'off'     , ...
  'XColor'      , [.3 .3 .3], ...
  'YColor'      , [.3 .3 .3], ...
  'XTick'       , 0:1:nsessions     , ...
  'XGrid'       , 'off'      , ...
  'YGrid'       , 'off'      , ...
  'LineWidth'   , 1         );
end

    
%% taste weight vs health weight
if plot_weight

    %-natural-cued condition
figure;

% subplot(1,2,1);
x = [1:nsessions];

y1(:,:) = b2(:,1:nsessions,1);
y2(:,:) = b1(:,1:nsessions,1);

y1m = mean(y1,1);
y2m = mean(y2,1);
y1h = []; y2h = [];
for sess = 1:nsessions
    hdi = HDIofMCMC(y1(:,sess),0.95);
    y1h(sess) = hdi(2) - hdi(1);
    
    hdi = HDIofMCMC(y2(:,sess),0.95);
    y2h(sess) = hdi(2) - hdi(1);
end

sh = shadedErrorBar_origin(x,y1m,y1h,'lineprops',{'LineStyle','-','LineWidth',0.5,'Color',color1+[0 26 51]/255});
component{1} = sh.mainLine;

hold on
sh  = shadedErrorBar_origin(x,y2m,y2h,'lineprops',{'LineStyle','-','LineWidth',0.5,'Color',color2+[153 102 51]/255});
component{2} = sh.mainLine;

hold on
plot(x,repmat(y1m(1),1,length(x)),'Color',color1,'LineStyle',':','LineWidth',2.5);
hold on
plot(x,repmat(y1m(nsessions),1,length(x)),'Color',color1,'LineStyle',':','LineWidth',2.5);


hold on
plot(x,repmat(y2m(1),1,length(x)),'Color',color2,'LineStyle',':','LineWidth',2.5);
hold on
plot(x,repmat(y2m(nsessions),1,length(x)),'Color',color2,'LineStyle',':','LineWidth',2.5);
xlabel('session');
ylabel('weight');

ylim([-1 2]);
% title('natural-cued condition');

hLegend = legend( ...
  [component{1}, component{2}], ...
  ['taste'] , ...
  ['health'] , ...
  'location', 'NorthWest');

legend boxoff;  

set(gca, ...
  'Box'         , 'off'     , ...
  'TickDir'     , 'out'     , ...
  'TickLength'  , [.02 .02] , ...
  'XMinorTick'  , 'off'     , ...
  'YMinorTick'  , 'off'     , ...
  'XColor'      , [.3 .3 .3], ...
  'YColor'      , [.3 .3 .3], ...
  'XTick'       , 0:1:nsessions     , ...
  'XGrid'       , 'off'      , ...
  'YGrid'       , 'off'      , ...
  'LineWidth'   , 1         );


%-health weight
% subplot(1,2,2);
figure;

y1(:,:) = b2(:,1:nsessions,2);
y2(:,:) = b1(:,1:nsessions,2);

y1m = mean(y1,1);
y2m = mean(y2,1);
y1h = []; y2h = [];
for sess = 1:nsessions
    hdi = HDIofMCMC(y1(:,sess),0.95);
    y1h(sess) = hdi(2) - hdi(1);
    
    hdi = HDIofMCMC(y2(:,sess),0.95);
    y2h(sess) = hdi(2) - hdi(1);
end

sh = shadedErrorBar_origin(x,y1m,y1h,'lineprops',{'LineStyle','-','LineWidth',.5,'Color',color1+[0 26 51]/255});
component{1} = sh.mainLine;

hold on
sh  = shadedErrorBar_origin(x,y2m,y2h,'lineprops',{'LineStyle','-','LineWidth',.5,'Color',color2+[153 102 51]/255});
component{2} = sh.mainLine;

hold on
plot(x,repmat(y1m(1),1,length(x)),'Color',color1,'LineStyle',':','LineWidth',2.5);
hold on
plot(x,repmat(y1m(nsessions),1,length(x)),'Color',color1,'LineStyle',':','LineWidth',2.5);


hold on
plot(x,repmat(y2m(1),1,length(x)),'Color',color2,'LineStyle',':','LineWidth',2.5);
hold on
plot(x,repmat(y2m(nsessions),1,length(x)),'Color',color2,'LineStyle',':','LineWidth',2.5);


xlabel('session');
ylabel('weight');

ylim([-1 2]);
% title('health-cued condition');

hLegend = legend( ...
  [component{1}, component{2}], ...
  ['taste'] , ...
  ['health'] , ...
  'location', 'NorthWest');

legend boxoff;  

set(gca, ...
  'Box'         , 'off'     , ...
  'TickDir'     , 'out'     , ...
  'TickLength'  , [.02 .02] , ...
  'XMinorTick'  , 'off'     , ...
  'YMinorTick'  , 'off'     , ...
  'XColor'      , [.3 .3 .3], ...
  'YColor'      , [.3 .3 .3], ...
  'XTick'       , 0:1:nsessions     , ...
  'XGrid'       , 'off'      , ...
  'YGrid'       , 'off'      , ...
  'LineWidth'   , 1         );

end

%%
if plot_rst
  
figure;   
x = [1:nsessions];

y1(:,:) = rst(:,1:nsessions,1);
y2(:,:) = rst(:,1:nsessions,2);

y1m = mean(y1,1);
y2m = mean(y2,1);
y1h = []; y2h = [];
for sess = 1:nsessions
    hdi = HDIofMCMC(y1(:,sess),0.95);
    y1h(sess) = hdi(2) - hdi(1);
    
    hdi = HDIofMCMC(y2(:,sess),0.95);
    y2h(sess) = hdi(2) - hdi(1);
end

sh = shadedErrorBar_origin(x,y1m,y1h,'lineprops',{'LineStyle','-','LineWidth',2,'Color',color1});
component{1} = sh.mainLine;

hold on
sh  = shadedErrorBar_origin(x,y2m,y2h,'lineprops',{'LineStyle','-','LineWidth',2,'Color',color2});
component{2} = sh.mainLine;

hold on
plot(x,repmat(y1m(1),1,length(x)),'Color',color1,'LineStyle',':','LineWidth',1.5);
hold on
plot(x,repmat(y1m(nsessions),1,length(x)),'Color',color1,'LineStyle',':','LineWidth',1.5);


hold on
plot(x,repmat(y2m(1),1,length(x)),'Color',color2,'LineStyle',':','LineWidth',1.5);
hold on
plot(x,repmat(y2m(nsessions),1,length(x)),'Color',color2,'LineStyle',':','LineWidth',1.5);



xlabel('session');
ylabel('rst');

% ylim([-.2 1]);
% title('RST');

hLegend = legend( ...
  [component{1}, component{2}], ...
  ['natural-cued condition'] , ...
  ['health-cued condition'] , ...
  'location', 'NorthWest');

legend boxoff;  

set(gca, ...
  'Box'         , 'off'     , ...
  'TickDir'     , 'out'     , ...
  'TickLength'  , [.02 .02] , ...
  'XMinorTick'  , 'off'     , ...
  'YMinorTick'  , 'off'     , ...
  'XColor'      , [.3 .3 .3], ...
  'YColor'      , [.3 .3 .3], ...
  'XTick'       , 0:1:nsessions     , ...
  'XGrid'       , 'off'      , ...
  'YGrid'       , 'off'      , ...
  'LineWidth'   , 1         );


    
end