function matrix_regression = reformat_datafor_brms_choices(sbjs,type,nsessions)
load('data_trials');

% we can have two kind of data structures: type 1 for left option vs right option and
% type 2 for the healthier chosen option vs not-healthier option.
neutUpper = 213 + 21;
neutLower = 213 - 21;

%--------------------------------------------------------------------------
data_regression = []; 
for sub = sbjs 
for sess = 1:nsessions
for t = 1:length(trials{sub}{sess}.choice)  
    %----------------------------------------------------------------------
    % specify the option of the study variable
    switch type
        case 1 %study variable (option) = left option, the other option = right
            data_regression{sub}{sess}.studyVariable1(t,1)  = 1; %left = 1, right = 2
            data_regression{sub}{sess}.studyVariable2(t,1)  = 2;

        case 2 %study variable (option) = healthier,   the other option = not-healthier
        if trials{sub}{sess}.food{1}.health(t) > trials{sub}{sess}.food{2}.health(t) 
            data_regression{sub}{sess}.studyVariable1(t,1)  = 1;
            data_regression{sub}{sess}.studyVariable2(t,1)  = 2;
        else
            data_regression{sub}{sess}.studyVariable1(t,1)  = 2;
            data_regression{sub}{sess}.studyVariable2(t,1)  = 1;
        end        
    end
    %----------------------------------------------------------------------   
    studyVariable1 = data_regression{sub}{sess}.studyVariable1(t,1);
    studyVariable2 = data_regression{sub}{sess}.studyVariable2(t,1);   
    %---------------------------------------------------------------------- 
    % specify the choice
    if isnan(trials{sub}{sess}.choice(t))
        data_regression{sub}{sess}.choice(t,1)  = NaN;        
    elseif trials{sub}{sess}.choice(t) == studyVariable1
        data_regression{sub}{sess}.choice(t,1)  = 1;
    else
        data_regression{sub}{sess}.choice(t,1)  = 0;
    end
    data_regression{sub}{sess}.rt(t,1) = trials{sub}{sess}.rt(t);
    %----------------------------------------------------------------------                   
    data_regression{sub}{sess}.studyVar1.health(t,1)  = trials{sub}{sess}.food{studyVariable1}.health(t);
    data_regression{sub}{sess}.studyVar1.taste(t,1)   = trials{sub}{sess}.food{studyVariable1}.taste(t);
    
    data_regression{sub}{sess}.studyVar2.health(t,1)  = trials{sub}{sess}.food{studyVariable2}.health(t);
    data_regression{sub}{sess}.studyVar2.taste(t,1)   = trials{sub}{sess}.food{studyVariable2}.taste(t);
    %----------------------------------------------------------------------       
    data_regression{sub}{sess}.subject(t,1)           = sub;
    data_regression{sub}{sess}.session(t,1)           = sess;
    data_regression{sub}{sess}.condition(t,1)         = trials{sub}{sess}.condition(t);
    %----------------------------------------------------------------------
    if  (trials{sub}{sess}.food{1}.health(t) > trials{sub}{sess}.food{2}.health(t)  && ...
         trials{sub}{sess}.food{1}.taste(t)  < trials{sub}{sess}.food{2}.taste(t))    ...
        || ...
        (trials{sub}{sess}.food{1}.health(t) < trials{sub}{sess}.food{2}.health(t)  && ...
         trials{sub}{sess}.food{1}.taste(t)  > trials{sub}{sess}.food{2}.taste(t))
            
        data_regression{sub}{sess}.challenge(t,1) = 1;             
    else
        data_regression{sub}{sess}.challenge(t,1) = 0;
    end        
%     % if any Hc,Hnc,Tc,or Tnc rating is in the neutral zone
%     if (trials{sub}{sess}.food{1}.health(t) > neutLower && trials{sub}{sess}.food{1}.health(t) < neutUpper) || ... 
%        (trials{sub}{sess}.food{1}.taste(t)  > neutLower && trials{sub}{sess}.food{1}.taste(t)  < neutUpper) || ... 
%        (trials{sub}{sess}.food{2}.health(t) > neutLower && trials{sub}{sess}.food{2}.health(t) < neutUpper) || ... 
%        (trials{sub}{sess}.food{2}.taste(t)  > neutLower && trials{sub}{sess}.food{2}.taste(t)  < neutUpper)
%           
%         data_regression{sub}{sess}.challenge(t,1) = NaN;  %#ok<*AGROW>
%     end
    %----------------------------------------------------------------------   
end
end
end
%%
% challenge_success = correct.choice;

%%  find missed trials
data_notmissed = [];
for sub = sbjs
    for sess = 1:nsessions
        data_notmissed{sub}{sess}.logical       = ~isnan(trials{sub}{sess}.choice);
        data_notmissed{sub}{sess}.indices       = find(data_notmissed{sub}{sess}.logical == 1);
    end
end 
%% construct data frame for regression 
%matrix = [subject,session,condition,challenge_success,health(correct),taste(correct),health(wrong),taste(wrong)]
sbj = []; session = []; condition = []; choice = []; rt = []; challenge = []; vh_1 = []; vt_1 = []; vh_2 = []; vt_2 = []; td = []; hd = [];
for sub = sbjs
    for sess = 1:nsessions
        notmissed = data_notmissed{sub}{sess}.indices;
                
        sbj         = [sbj;         data_regression{sub}{sess}.subject(notmissed)]; 
        session     = [session;     data_regression{sub}{sess}.session(notmissed)];
        condition   = [condition;   data_regression{sub}{sess}.condition(notmissed)];
        choice      = [choice;      data_regression{sub}{sess}.choice(notmissed)];      
        rt          = [rt;          data_regression{sub}{sess}.rt(notmissed)];
        challenge   = [challenge;   data_regression{sub}{sess}.challenge(notmissed)];
        vt_1        = [vt_1;        data_regression{sub}{sess}.studyVar1.taste(notmissed)];
        vt_2        = [vt_2;        data_regression{sub}{sess}.studyVar2.taste(notmissed)];
        vh_1        = [vh_1;        data_regression{sub}{sess}.studyVar1.health(notmissed)];
        vh_2        = [vh_2;        data_regression{sub}{sess}.studyVar2.health(notmissed)];
    end
end

td = [zscore(vt_1) - zscore(vt_2)];
hd = [zscore(vh_1) - zscore(vh_2)];           

matrix_regression = [choice,challenge,vt_1,vt_2,vh_1,vh_2,td,hd,sbj,session,condition,rt];

%% 
Data.choice     = matrix_regression(:, 1);  %choice;
Data.challenge  = matrix_regression(:, 2);  %challenge;
Data.vt_1       = matrix_regression(:, 3);  %vt_1;
Data.vt_2       = matrix_regression(:, 4);  %vt_2;
Data.vh_1       = matrix_regression(:, 5);  %vh_1;
Data.vh_2       = matrix_regression(:, 6);  %vh_2;
Data.td         = matrix_regression(:, 7);  %td;
Data.hd         = matrix_regression(:, 8);  %hd;
Data.subject    = matrix_regression(:, 9);  %subject;
Data.session    = matrix_regression(:,10);  %session;
Data.condition  = matrix_regression(:,11);  %condition;
Data.rt         = matrix_regression(:,12);  %rt;

save(['data_brms_choice',num2str(type)],'Data');








