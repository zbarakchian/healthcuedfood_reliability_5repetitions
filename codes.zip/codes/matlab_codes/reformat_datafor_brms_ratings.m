function reformat_datafor_brms_ratings(sbjs,nsessions)

load('data_ratings2');

ntrials         = 60;
images_all      = [1:180]';
images_spanned  = [4 5 7 8 10 11 15 19 20 21 30 31 34 36 37 39 47 55 59 64 67 68 69      ...
                   70 71 72 74 78 80 83 87 88 89 90 95 101 106 107 108 109 110 117       ...
                   120 121 122 124 125 126 128 132 149 154 156 158 161 163 166 168 169 178]';
               
features        = {'taste','health'};

neutUpper       = 213 + 21;
neutLower       = 213 - 21;


%-specify the categories
%--------------------------------------------------------------------------
ctg = healthy_tasty_else(sbjs); %1=fully tasty, 2=fully healthy, 3=else

%--------------------------------------------------------------------------
data_regression = []; 
for sub = sbjs 
for sess = 1:nsessions   indx = 1;
for f = 1:2   
for t = 1:ntrials
    rate = ratings_span{sub}{sess}.(features{f});
    %----------------------------------------------------------------------       
    data_regression{sub}{sess}.subject(indx,1)      = sub;
    data_regression{sub}{sess}.session(indx,1)      = sess;
    data_regression{sub}{sess}.rating(indx,1)       = rate(t,2);
    data_regression{sub}{sess}.category(indx,1)     = ctg(t);
    data_regression{sub}{sess}.dimension(indx,1)    = f;
    %----------------------------------------------------------------------   
    indx = indx + 1;
end
end
end
end
%%

disp('hey');

%% construct data frame for regression 
%matrix = [subject,session,rating,category,dimension,b1,b2,rst]
sbj = []; session = []; rating = []; category = []; dimension = []; b1 = []; b2 = []; rst = [];
for sub = sbjs
    for sess = 1:nsessions                
        sbj         = [sbj;         data_regression{sub}{sess}.subject]; 
        session     = [session;     data_regression{sub}{sess}.session];
        rating      = [rating;      data_regression{sub}{sess}.rating];
        category    = [category;    data_regression{sub}{sess}.category];      
        dimension   = [dimension;   data_regression{sub}{sess}.dimension];
    end
end           

matrix_regression = [rating,sbj,session,dimension,category,b1,b2,rst];

%% 
Data.rating     = matrix_regression(:, 1);  
Data.sbj        = matrix_regression(:, 2);  
Data.session    = matrix_regression(:, 3);  
Data.dimension  = matrix_regression(:, 4);  
Data.category   = matrix_regression(:, 5);

save(['data_brms_rating'],'Data');



