function matrix_DDM = reformat_datafor_ddm(sbjs,type)

% HstDDM
% we can have two kind of data structures: 
% one for left chosen option and
% the other for the healthy chosen option.

%%% data variables:
%--------------------------------------------------------------------------
%% Type 1
% choice  -> =1 if left food item chosen, =0 if right food item chosen
% vt_1    -> value taste  food item on the left  hand side of the screen
% vt_2    -> value taste  food item on the right hand side of the screen
% vh_1    -> value health food item on the left  hand side of the screen
% vh_2    -> value health food item on the right hand side of the screen
% td      -> value difference in taste
% hd      -> value difference in health
% rt      -> reaction time in seconds
% subject -> subject number
%--------------------------------------------------------------------------
%% Type2
% choice  -> =1 if haelthier food item chosen, =0 if not-healthier food item chosen
% vt_1    -> value taste  food item of the     healthier one
% vt_2    -> value taste  food item of the not-healthier one
% vh_1    -> value health food item of the     healthier one
% vh_2    -> value health food item of the not-healthier one
% td      -> value difference in taste
% hd      -> value difference in health
% rt      -> reaction time in seconds
% subject -> subject number
%--------------------------------------------------------------------------

%% find the studyVar1 option data for entering to the regression
neutUpper = 213 + 21;
neutLower = 213 - 21;

load('data_trials');
%--------------------------------------------------------------------------
data_regression = []; 
for sub = sbjs 
for sess = 1:length(trials{sub})
for t = 1:length(trials{sub}{sess}.choice)  
    %----------------------------------------------------------------------
    % specify the option of the study variable
    switch type
        case 1 %study variable (option) = left option, the other option = right
            data_regression{sub}{sess}.studyVariable1(t,1)  = 1;
            data_regression{sub}{sess}.studyVariable2(t,1)  = 2;

        case 2 %study variable (option) = healthier,   the other option = not-healthier
        if trials{sub}{sess}.food{1}.health(t) > trials{sub}{sess}.food{2}.health(t) 
            data_regression{sub}{sess}.studyVariable1(t,1)  = 1;
            data_regression{sub}{sess}.studyVariable2(t,1)  = 2;
        else
            data_regression{sub}{sess}.studyVariable1(t,1)  = 2;
            data_regression{sub}{sess}.studyVariable2(t,1)  = 1;
        end        
    end
    %----------------------------------------------------------------------   
    studyVariable1 = data_regression{sub}{sess}.studyVariable1(t,1);
    studyVariable2 = data_regression{sub}{sess}.studyVariable2(t,1);   
    %---------------------------------------------------------------------- 
    % specify the choice
    if isnan(trials{sub}{sess}.choice(t))
        data_regression{sub}{sess}.choice(t,1)  = NaN;        
    elseif trials{sub}{sess}.choice(t) == studyVariable1
        data_regression{sub}{sess}.choice(t,1)  = 1;
    else
        data_regression{sub}{sess}.choice(t,1)  = 0;
    end
    data_regression{sub}{sess}.rt(t,1) = trials{sub}{sess}.rt(t);
    %----------------------------------------------------------------------                   
    data_regression{sub}{sess}.studyVar1.health(t,1)  = trials{sub}{sess}.food{studyVariable1}.health(t);
    data_regression{sub}{sess}.studyVar1.taste(t,1)   = trials{sub}{sess}.food{studyVariable1}.taste(t);
    
    data_regression{sub}{sess}.studyVar2.health(t,1)  = trials{sub}{sess}.food{studyVariable2}.health(t);
    data_regression{sub}{sess}.studyVar2.taste(t,1)   = trials{sub}{sess}.food{studyVariable2}.taste(t);
    %----------------------------------------------------------------------       
    data_regression{sub}{sess}.subject(t,1)           = sub;
    data_regression{sub}{sess}.session(t,1)           = sess;
    data_regression{sub}{sess}.condition(t,1)         = trials{sub}{sess}.condition(t);
    %----------------------------------------------------------------------
    if  (trials{sub}{sess}.food{1}.health(t) > trials{sub}{sess}.food{2}.health(t)  && ...
         trials{sub}{sess}.food{1}.taste(t)  < trials{sub}{sess}.food{2}.taste(t))    ...
        || ...
        (trials{sub}{sess}.food{1}.health(t) < trials{sub}{sess}.food{2}.health(t)  && ...
         trials{sub}{sess}.food{1}.taste(t)  > trials{sub}{sess}.food{2}.taste(t))
            
        data_regression{sub}{sess}.challenge(t,1) = 1;             
    else
        data_regression{sub}{sess}.challenge(t,1) = 0;
    end        
    % if any Hc,Hnc,Tc,or Tnc rating is in the neutral zone
%     if (trials{sub}{sess}.food{1}.health(t) > neutLower && trials{sub}{sess}.food{1}.health(t) < neutUpper) || ... 
%        (trials{sub}{sess}.food{1}.taste(t)  > neutLower && trials{sub}{sess}.food{1}.taste(t)  < neutUpper) || ... 
%        (trials{sub}{sess}.food{2}.health(t) > neutLower && trials{sub}{sess}.food{2}.health(t) < neutUpper) || ... 
%        (trials{sub}{sess}.food{2}.taste(t)  > neutLower && trials{sub}{sess}.food{2}.taste(t)  < neutUpper)
%           
%         data_regression{sub}{sess}.challenge(t,1) = NaN; 
%     end
    %----------------------------------------------------------------------   
end
end
end
%--------------------------------------------------------------------------
%--------------------------------------------------------------------------


%%  find missed trials
data_notmissed = [];
for sub = sbjs
    for sess = 1:length(trials{sub})
        data_notmissed{sub}{sess}.logical       = ~isnan(trials{sub}{sess}.choice);
        data_notmissed{sub}{sess}.indices       = find(data_notmissed{sub}{sess}.logical == 1);
    end
end 
%% construct data frame for ddm/regression 
%matrix = [subject,challenge_success,health(studyVar1),taste(studyVar1),health(studyVar2),taste(studyVar2)]
matrix_DDM = [];
for sess = 1:5
    for cond = [1,2]  % = cond 0,1        
        sbj  = []; choice = []; rt = []; challenge = []; vh_1 = []; vt_1 = []; vh_2 = []; vt_2 = []; td   = []; hd = []; 
        
        for sub = sbjs
        %------------------------------------------------------------------
        Indx_notmissed  = data_notmissed{sub}{sess}.indices;
        Indx_cond{cond} = find(trials{sub}{sess}.condition == cond-1);
        Indx = intersect(Indx_notmissed,Indx_cond{cond});
        %------------------------------------------------------------------
        sbj         = [sbj;         data_regression{sub}{sess}.subject(Indx)]; 
        choice      = [choice;      data_regression{sub}{sess}.choice(Indx)];      
        rt          = [rt;          data_regression{sub}{sess}.rt(Indx)];
        challenge   = [challenge;   data_regression{sub}{sess}.challenge(Indx)];
        vt_1        = [vt_1;        data_regression{sub}{sess}.studyVar1.taste(Indx)];
        vt_2        = [vt_2;        data_regression{sub}{sess}.studyVar2.taste(Indx)];
        vh_1        = [vh_1;        data_regression{sub}{sess}.studyVar1.health(Indx)];
        vh_2        = [vh_2;        data_regression{sub}{sess}.studyVar2.health(Indx)];
        td          = [vt_1 - vt_2];
        hd          = [vh_1 - vh_2];

        matrix_DDM{sess}{cond} = [choice,vt_1,vt_2,vh_1,vh_2,td,hd,rt,sbj,challenge]; 
        %------------------------------------------------------------------
        end
    end  
end
save(strcat('data_ddm',num2str(type)),'matrix_DDM');


%%
for sess = 1:length(trials{sub})
    for cond = [1,2]  %= cond 0,1

        Temp = matrix_DDM{sess}{cond};
        
        Data.choice     = Temp(:,1);  %choice;
%         Data.vt_l       = Temp(:,2);  %vt_1;
%         Data.vt_r       = Temp(:,3);  %vt_2;
%         Data.vh_l       = Temp(:,4);  %vh_1;
%         Data.vh_r       = Temp(:,5);  %vh_2;
        Data.vt_1       = Temp(:,2);  %vt_1;
        Data.vt_2       = Temp(:,3);  %vt_2;
        Data.vh_1       = Temp(:,4);  %vh_1;
        Data.vh_2       = Temp(:,5);  %vh_2;
        
        Data.td         = Temp(:,6);  %td;
        Data.hd         = Temp(:,7);  %hd;
        Data.rt         = Temp(:,8);  %rt;
        Data.subject    = Temp(:,9);  %sbj;
        Data.challenge  = Temp(:,10); %challenge;

        nameVar = ['data_ddm',num2str(type),'_sess' num2str(sess) 'cond' num2str(cond-1) ];
%         eval([nameVar ' = Data']);
        save(nameVar, 'Data');

    end
end


disp('*** END ***');
%%







