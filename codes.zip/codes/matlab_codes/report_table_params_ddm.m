load('results1_ddm');
nparams = 7;

%b0,b1,b2,time,theta,bias,alpha

% Health: b1
% Taste: b2
% Drift: mean(b1,b2)
% Non-decision time: theta
% Bias: bias
% Noise: alpha
% Drift bias: b0


parameters = [];
for sess = 1:5
    for cond = 1:2
        params = ddm{sess,cond};
        
        for sub = 1:23
            params.drift(sub) = params.b0(sub) + params.b1(sub) + params.b2(sub);      
        end
        
        for sub = 1:23
            parameters{sess,cond}(1,sub)      = params.b1(sub);
            parameters{sess,cond}(2,sub)      = params.b2(:,sub);
            parameters{sess,cond}(3,sub)      = params.drift(:,sub);
            parameters{sess,cond}(4,sub)      = params.theta(:,sub);
            parameters{sess,cond}(5,sub)      = params.bias(:,sub);
            parameters{sess,cond}(6,sub)      = params.alpha(:,sub);
            parameters{sess,cond}(7,sub)      = params.b0(:,sub);
           
        end
    end
end

    
tmp1 = [];
tmp2 = [];
  
for sess = 1:5
for cond = 1:2
    for i = 1:nparams
        tmp1(i,cond,sess) = mean(parameters{sess,cond}(i,:),2);
        tmp2(i,cond,sess) = std(parameters{sess,cond}(i,:),0);
    end
end
end


tble.mean  = tmp1;
tble.std   = tmp2;
tble.mean  = round(tmp1,3);
tble.std   = round(tmp2,3);


tble_latex = [];
for sess = 1:5
for cond = 1:2
for i = 1:nparams
    tble_latex{sess}{i,cond} = ['$' num2str(tble.mean(i,cond,sess)) ' \pm ' num2str(tble.std(i,cond,sess)) '$'];
%     disp(tble_latex{i});
end
end
end

disp('');


